const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
/**
* Hook that records user microphone audio while holding the button (push-to-talk).
* On release (stop), the complete recorded audio blob is emitted to `onAudioBlob`.
*/
export function useRecorder(onAudioBlob) {
	const [isRecording, setIsRecording] = useState(false);
	const [error, setError] = useState(null);
	const mediaRecorderRef = useRef(null);
	const chunksRef = useRef([]);
	const streamRef = useRef(null);
	const start = useCallback(async () => {
		try {
			setError(null);
			if (!navigator.mediaDevices || !window.MediaRecorder) {
				throw new Error("Audio recording is not supported in this browser.");
			}
			const stream = await navigator.mediaDevices.getUserMedia({ audio: {
				channelCount: 1,
				sampleRate: 16e3,
				echoCancellation: true,
				noiseSuppression: true
			} });
			streamRef.current = stream;
			// Select supported MIME type
			let mimeType = "audio/webm;codecs=opus";
			if (!MediaRecorder.isTypeSupported(mimeType)) {
				mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : MediaRecorder.isTypeSupported("audio/mp4") ? "audio/mp4" : "";
			}
			const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
			chunksRef.current = [];
			recorder.ondataavailable = (e) => {
				if (e.data && e.data.size > 0) {
					chunksRef.current.push(e.data);
				}
			};
			recorder.onstop = () => {
				if (chunksRef.current.length > 0) {
					const mime = recorder.mimeType || "audio/webm";
					const finalBlob = new Blob(chunksRef.current, { type: mime });
					// Only send if audio contains actual data (avoids empty click jitter)
					if (finalBlob.size > 500) {
						onAudioBlob(finalBlob);
					}
					chunksRef.current = [];
				}
			};
			recorder.start(100);
			mediaRecorderRef.current = recorder;
			setIsRecording(true);
		} catch (err) {
			console.error("Failed to start recording:", err);
			setError(err?.message || "Microphone access denied");
			setIsRecording(false);
		}
	}, [onAudioBlob]);
	const stop = useCallback(() => {
		if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
			mediaRecorderRef.current.stop();
		}
		if (streamRef.current) {
			streamRef.current.getTracks().forEach((t) => t.stop());
			streamRef.current = null;
		}
		setIsRecording(false);
	}, []);
	useEffect(() => {
		return () => {
			stop();
		};
	}, [stop]);
	return {
		isRecording,
		error,
		start,
		stop
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFFBQVEsYUFBYSxpQkFBaUI7Ozs7O0FBTXpELE9BQU8sU0FBUyxZQUFZLGFBQW1DO0NBQzdELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUF3QixJQUFJO0NBQ3RELE1BQU0sbUJBQW1CLE9BQTZCLElBQUk7Q0FDMUQsTUFBTSxZQUFZLE9BQWUsQ0FBQyxDQUFDO0NBQ25DLE1BQU0sWUFBWSxPQUEyQixJQUFJO0NBRWpELE1BQU0sUUFBUSxZQUFZLFlBQVk7RUFDcEMsSUFBSTtHQUNGLFNBQVMsSUFBSTtHQUNiLElBQUksQ0FBQyxVQUFVLGdCQUFnQixDQUFDLE9BQU8sZUFBZTtJQUNwRCxNQUFNLElBQUksTUFBTSxtREFBbUQ7R0FDckU7R0FFQSxNQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYSxFQUN2RCxPQUFPO0lBQ0wsY0FBYztJQUNkLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsa0JBQWtCO0dBQ3BCLEVBQ0YsQ0FBQztHQUNELFVBQVUsVUFBVTs7R0FHcEIsSUFBSSxXQUFXO0dBQ2YsSUFBSSxDQUFDLGNBQWMsZ0JBQWdCLFFBQVEsR0FBRztJQUM1QyxXQUFXLGNBQWMsZ0JBQWdCLFlBQVksSUFDakQsZUFDQSxjQUFjLGdCQUFnQixXQUFXLElBQ3pDLGNBQ0E7R0FDTjtHQUVBLE1BQU0sV0FBVyxXQUFXLElBQUksY0FBYyxRQUFRLEVBQUUsU0FBUyxDQUFDLElBQUksSUFBSSxjQUFjLE1BQU07R0FDOUYsVUFBVSxVQUFVLENBQUM7R0FFckIsU0FBUyxtQkFBbUIsTUFBTTtJQUNoQyxJQUFJLEVBQUUsUUFBUSxFQUFFLEtBQUssT0FBTyxHQUFHO0tBQzdCLFVBQVUsUUFBUSxLQUFLLEVBQUUsSUFBSTtJQUMvQjtHQUNGO0dBRUEsU0FBUyxlQUFlO0lBQ3RCLElBQUksVUFBVSxRQUFRLFNBQVMsR0FBRztLQUNoQyxNQUFNLE9BQU8sU0FBUyxZQUFZO0tBQ2xDLE1BQU0sWUFBWSxJQUFJLEtBQUssVUFBVSxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7O0tBRTVELElBQUksVUFBVSxPQUFPLEtBQUs7TUFDeEIsWUFBWSxTQUFTO0tBQ3ZCO0tBQ0EsVUFBVSxVQUFVLENBQUM7SUFDdkI7R0FDRjtHQUVBLFNBQVMsTUFBTSxHQUFHO0dBQ2xCLGlCQUFpQixVQUFVO0dBQzNCLGVBQWUsSUFBSTtFQUNyQixTQUFTLEtBQVU7R0FDakIsUUFBUSxNQUFNLDhCQUE4QixHQUFHO0dBQy9DLFNBQVMsS0FBSyxXQUFXLDBCQUEwQjtHQUNuRCxlQUFlLEtBQUs7RUFDdEI7Q0FDRixHQUFHLENBQUMsV0FBVyxDQUFDO0NBRWhCLE1BQU0sT0FBTyxrQkFBa0I7RUFDN0IsSUFBSSxpQkFBaUIsV0FBVyxpQkFBaUIsUUFBUSxVQUFVLGFBQWE7R0FDOUUsaUJBQWlCLFFBQVEsS0FBSztFQUNoQztFQUNBLElBQUksVUFBVSxTQUFTO0dBQ3JCLFVBQVUsUUFBUSxVQUFVLENBQUMsQ0FBQyxTQUFTLE1BQU0sRUFBRSxLQUFLLENBQUM7R0FDckQsVUFBVSxVQUFVO0VBQ3RCO0VBQ0EsZUFBZSxLQUFLO0NBQ3RCLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZ0JBQWdCO0VBQ2QsYUFBYTtHQUNYLEtBQUs7RUFDUDtDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxPQUFPO0VBQUU7RUFBYTtFQUFPO0VBQU87Q0FBSztBQUMzQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ1c2VSZWNvcmRlci50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogSG9vayB0aGF0IHJlY29yZHMgdXNlciBtaWNyb3Bob25lIGF1ZGlvIHdoaWxlIGhvbGRpbmcgdGhlIGJ1dHRvbiAocHVzaC10by10YWxrKS5cbiAqIE9uIHJlbGVhc2UgKHN0b3ApLCB0aGUgY29tcGxldGUgcmVjb3JkZWQgYXVkaW8gYmxvYiBpcyBlbWl0dGVkIHRvIGBvbkF1ZGlvQmxvYmAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VSZWNvcmRlcihvbkF1ZGlvQmxvYjogKGJsb2I6IEJsb2IpID0+IHZvaWQpIHtcbiAgY29uc3QgW2lzUmVjb3JkaW5nLCBzZXRJc1JlY29yZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IG1lZGlhUmVjb3JkZXJSZWYgPSB1c2VSZWY8TWVkaWFSZWNvcmRlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBjaHVua3NSZWYgPSB1c2VSZWY8QmxvYltdPihbXSk7XG4gIGNvbnN0IHN0cmVhbVJlZiA9IHVzZVJlZjxNZWRpYVN0cmVhbSB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHN0YXJ0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgIGlmICghbmF2aWdhdG9yLm1lZGlhRGV2aWNlcyB8fCAhd2luZG93Lk1lZGlhUmVjb3JkZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXVkaW8gcmVjb3JkaW5nIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBicm93c2VyLlwiKTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEoe1xuICAgICAgICBhdWRpbzoge1xuICAgICAgICAgIGNoYW5uZWxDb3VudDogMSxcbiAgICAgICAgICBzYW1wbGVSYXRlOiAxNjAwMCxcbiAgICAgICAgICBlY2hvQ2FuY2VsbGF0aW9uOiB0cnVlLFxuICAgICAgICAgIG5vaXNlU3VwcHJlc3Npb246IHRydWUsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gc3RyZWFtO1xuXG4gICAgICAvLyBTZWxlY3Qgc3VwcG9ydGVkIE1JTUUgdHlwZVxuICAgICAgbGV0IG1pbWVUeXBlID0gXCJhdWRpby93ZWJtO2NvZGVjcz1vcHVzXCI7XG4gICAgICBpZiAoIU1lZGlhUmVjb3JkZXIuaXNUeXBlU3VwcG9ydGVkKG1pbWVUeXBlKSkge1xuICAgICAgICBtaW1lVHlwZSA9IE1lZGlhUmVjb3JkZXIuaXNUeXBlU3VwcG9ydGVkKFwiYXVkaW8vd2VibVwiKVxuICAgICAgICAgID8gXCJhdWRpby93ZWJtXCJcbiAgICAgICAgICA6IE1lZGlhUmVjb3JkZXIuaXNUeXBlU3VwcG9ydGVkKFwiYXVkaW8vbXA0XCIpXG4gICAgICAgICAgPyBcImF1ZGlvL21wNFwiXG4gICAgICAgICAgOiBcIlwiO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZWNvcmRlciA9IG1pbWVUeXBlID8gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlIH0pIDogbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtKTtcbiAgICAgIGNodW5rc1JlZi5jdXJyZW50ID0gW107XG5cbiAgICAgIHJlY29yZGVyLm9uZGF0YWF2YWlsYWJsZSA9IChlKSA9PiB7XG4gICAgICAgIGlmIChlLmRhdGEgJiYgZS5kYXRhLnNpemUgPiAwKSB7XG4gICAgICAgICAgY2h1bmtzUmVmLmN1cnJlbnQucHVzaChlLmRhdGEpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICByZWNvcmRlci5vbnN0b3AgPSAoKSA9PiB7XG4gICAgICAgIGlmIChjaHVua3NSZWYuY3VycmVudC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgbWltZSA9IHJlY29yZGVyLm1pbWVUeXBlIHx8IFwiYXVkaW8vd2VibVwiO1xuICAgICAgICAgIGNvbnN0IGZpbmFsQmxvYiA9IG5ldyBCbG9iKGNodW5rc1JlZi5jdXJyZW50LCB7IHR5cGU6IG1pbWUgfSk7XG4gICAgICAgICAgLy8gT25seSBzZW5kIGlmIGF1ZGlvIGNvbnRhaW5zIGFjdHVhbCBkYXRhIChhdm9pZHMgZW1wdHkgY2xpY2sgaml0dGVyKVxuICAgICAgICAgIGlmIChmaW5hbEJsb2Iuc2l6ZSA+IDUwMCkge1xuICAgICAgICAgICAgb25BdWRpb0Jsb2IoZmluYWxCbG9iKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY2h1bmtzUmVmLmN1cnJlbnQgPSBbXTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgcmVjb3JkZXIuc3RhcnQoMTAwKTtcbiAgICAgIG1lZGlhUmVjb3JkZXJSZWYuY3VycmVudCA9IHJlY29yZGVyO1xuICAgICAgc2V0SXNSZWNvcmRpbmcodHJ1ZSk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc3RhcnQgcmVjb3JkaW5nOlwiLCBlcnIpO1xuICAgICAgc2V0RXJyb3IoZXJyPy5tZXNzYWdlIHx8IFwiTWljcm9waG9uZSBhY2Nlc3MgZGVuaWVkXCIpO1xuICAgICAgc2V0SXNSZWNvcmRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfSwgW29uQXVkaW9CbG9iXSk7XG5cbiAgY29uc3Qgc3RvcCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAobWVkaWFSZWNvcmRlclJlZi5jdXJyZW50ICYmIG1lZGlhUmVjb3JkZXJSZWYuY3VycmVudC5zdGF0ZSA9PT0gXCJyZWNvcmRpbmdcIikge1xuICAgICAgbWVkaWFSZWNvcmRlclJlZi5jdXJyZW50LnN0b3AoKTtcbiAgICB9XG4gICAgaWYgKHN0cmVhbVJlZi5jdXJyZW50KSB7XG4gICAgICBzdHJlYW1SZWYuY3VycmVudC5nZXRUcmFja3MoKS5mb3JFYWNoKCh0KSA9PiB0LnN0b3AoKSk7XG4gICAgICBzdHJlYW1SZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIHNldElzUmVjb3JkaW5nKGZhbHNlKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHN0b3AoKTtcbiAgICB9O1xuICB9LCBbc3RvcF0pO1xuXG4gIHJldHVybiB7IGlzUmVjb3JkaW5nLCBlcnJvciwgc3RhcnQsIHN0b3AgfTtcbn1cbiJdfQ==