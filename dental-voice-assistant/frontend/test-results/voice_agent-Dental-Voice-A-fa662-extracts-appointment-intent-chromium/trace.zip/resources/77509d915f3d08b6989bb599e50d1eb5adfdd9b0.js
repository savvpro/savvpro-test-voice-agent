import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DebugPanel.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
var _jsxFileName = "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/DebugPanel.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4faeb0b1";
var _s = $RefreshSig$();
export function DebugPanel({ latestTurn }) {
	_s();
	const [showRaw, setShowRaw] = useState(false);
	if (!latestTurn) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "debug-panel card",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-title-bar",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "🧠 Brain State & NLU Inspector" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "badge badge-neutral",
					children: "Standby"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "empty-state-text",
				children: "Start a call to inspect real-time state machine transitions and slots."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this);
	}
	const { state, turn, slots, timings, action } = latestTurn;
	const slotEntries = slots ? Object.entries(slots) : [];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "debug-panel card",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-title-bar",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "🧠 Brain State & NLU Inspector" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "badge badge-accent",
					children: ["Turn ", turn]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "debug-grid",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "debug-stat-box",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "stat-label",
						children: "Current FSM State"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "state-badge-highlight",
						children: state || "START"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this), action && /* @__PURE__ */ _jsxDEV("div", {
					className: "debug-stat-box",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "stat-label",
						children: "Action Executed"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "badge badge-success",
						children: action
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			timings && /* @__PURE__ */ _jsxDEV("div", {
				className: "timings-section",
				children: [/* @__PURE__ */ _jsxDEV("h4", { children: "Latency Breakdown" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "timings-grid",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "timing-chip",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "timing-label",
								children: "STT (Whisper)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "timing-value",
								children: [Math.round(timings.stt_ms), " ms"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "timing-chip",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "timing-label",
								children: "Brain (FSM NLU)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "timing-value highlight-fast",
								children: [Math.round(timings.brain_ms), " ms"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "timing-chip",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "timing-label",
								children: "TTS (Voice)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "timing-value",
								children: [Math.round(timings.tts_ms), " ms"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "timing-chip timing-total",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "timing-label",
								children: "Round-Trip Total"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "timing-value",
								children: [Math.round(timings.total_ms), " ms"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "slots-section",
				children: [/* @__PURE__ */ _jsxDEV("h4", { children: "Extracted Context Slots" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this), slotEntries.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "no-data",
					children: "No slots populated yet."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("table", {
					className: "slots-table",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("th", { children: "Slot" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("th", { children: "Extracted Value" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: slotEntries.map(([k, v]) => /* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
						className: "slot-key",
						children: k
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("td", {
						className: "slot-val",
						children: v !== null && v !== undefined ? String(v) : "—"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 19
					}, this)] }, k, true, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 17
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "raw-toggle-row",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn btn-outline",
					onClick: () => setShowRaw((prev) => !prev),
					children: showRaw ? "Hide Raw Frame JSON" : "View Raw Frame JSON"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			showRaw && /* @__PURE__ */ _jsxDEV("pre", {
				className: "raw-json-viewer",
				children: JSON.stringify(latestTurn, null, 2)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_s(DebugPanel, "3UOdaLV+v/KJU1qtWDkOymguedU=");
_c = DebugPanel;
var _c;
$RefreshReg$(_c, "DebugPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DebugPanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/DebugPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/DebugPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/DebugPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7QUFPekIsT0FBTyxTQUFTLFdBQVcsRUFBRSxjQUErQjs7Q0FDMUQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FFNUMsSUFBSSxDQUFDLFlBQVk7RUFDZixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGlDQUFrQzs7OztjQUN0Qyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFzQjtJQUFhOzs7O1lBQ2hEOzs7OzthQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW1CO0dBQXlFOzs7O1dBQ3RHOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sRUFBRSxPQUFPLE1BQU0sT0FBTyxTQUFTLFdBQVc7Q0FDaEQsTUFBTSxjQUFjLFFBQVEsT0FBTyxRQUFRLEtBQUssSUFBSSxDQUFDO0NBRXJELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksaUNBQWtDOzs7O2NBQ3RDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQXFDLFNBQU0sSUFBVzs7Ozs7WUFDbkQ7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWE7S0FBdUI7Ozs7ZUFDcEQsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXlCLFNBQVM7S0FBYzs7OzthQUM3RDs7Ozs7Y0FFSixVQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBYTtLQUFxQjs7OztlQUNsRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBdUI7S0FBYTs7OzthQUNqRDs7Ozs7WUFFSjs7Ozs7O0dBRUosV0FDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLG9CQUFxQjs7OztjQUN6Qix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZTtPQUFtQjs7OztpQkFDbEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWdDLEtBQUssTUFBTSxRQUFRLE1BQU0sR0FBRSxLQUFTOzs7OztlQUNqRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZTtPQUFxQjs7OztpQkFDcEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQStDLEtBQUssTUFBTSxRQUFRLFFBQVEsR0FBRSxLQUFTOzs7OztlQUNsRjs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZTtPQUFpQjs7OztpQkFDaEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWdDLEtBQUssTUFBTSxRQUFRLE1BQU0sR0FBRSxLQUFTOzs7OztlQUNqRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZTtPQUFzQjs7OztpQkFDckQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWdDLEtBQUssTUFBTSxRQUFRLFFBQVEsR0FBRSxLQUFTOzs7OztlQUNuRTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksMEJBQTJCOzs7O2NBQzlCLFlBQVksV0FBVyxJQUN0Qix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFVO0lBQTBCOzs7O2VBRWpELHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksT0FBUTs7OztlQUNaLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7YUFDckI7Ozs7Y0FDQzs7OztlQUNQLHdCQUFDLFNBQUQsWUFDRyxZQUFZLEtBQUssQ0FBQyxHQUFHLE9BQ3BCLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBWTtLQUFNOzs7O2VBQ2hDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFZLE1BQU0sUUFBUSxNQUFNLFlBQVksT0FBTyxDQUFDLElBQUk7S0FBUTs7OzthQUM1RSxLQUhLOzs7O1lBR0wsQ0FDTCxFQUNJOzs7O2FBQ0Y7Ozs7O1lBRU47Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsZUFBZSxZQUFZLFNBQVMsQ0FBQyxJQUFJO2VBRXhDLFVBQVUsd0JBQXdCO0lBQzdCOzs7OztHQUNMOzs7OztHQUVKLFdBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7R0FDaEM7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRlYnVnUGFuZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IFR1cm5NZXNzYWdlIH0gZnJvbSBcIi4uL3R5cGVzXCI7XG5cbmludGVyZmFjZSBEZWJ1Z1BhbmVsUHJvcHMge1xuICBsYXRlc3RUdXJuOiBUdXJuTWVzc2FnZSB8IG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBEZWJ1Z1BhbmVsKHsgbGF0ZXN0VHVybiB9OiBEZWJ1Z1BhbmVsUHJvcHMpIHtcbiAgY29uc3QgW3Nob3dSYXcsIHNldFNob3dSYXddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGlmICghbGF0ZXN0VHVybikge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYnVnLXBhbmVsIGNhcmRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbC10aXRsZS1iYXJcIj5cbiAgICAgICAgICA8aDM+8J+noCBCcmFpbiBTdGF0ZSAmIE5MVSBJbnNwZWN0b3I8L2gzPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJhZGdlLW5ldXRyYWxcIj5TdGFuZGJ5PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZW1wdHktc3RhdGUtdGV4dFwiPlN0YXJ0IGEgY2FsbCB0byBpbnNwZWN0IHJlYWwtdGltZSBzdGF0ZSBtYWNoaW5lIHRyYW5zaXRpb25zIGFuZCBzbG90cy48L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgeyBzdGF0ZSwgdHVybiwgc2xvdHMsIHRpbWluZ3MsIGFjdGlvbiB9ID0gbGF0ZXN0VHVybjtcbiAgY29uc3Qgc2xvdEVudHJpZXMgPSBzbG90cyA/IE9iamVjdC5lbnRyaWVzKHNsb3RzKSA6IFtdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkZWJ1Zy1wYW5lbCBjYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLXRpdGxlLWJhclwiPlxuICAgICAgICA8aDM+8J+noCBCcmFpbiBTdGF0ZSAmIE5MVSBJbnNwZWN0b3I8L2gzPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiYWRnZS1hY2NlbnRcIj5UdXJuIHt0dXJufTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYnVnLWdyaWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWJ1Zy1zdGF0LWJveFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN0YXQtbGFiZWxcIj5DdXJyZW50IEZTTSBTdGF0ZTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0ZS1iYWRnZS1oaWdobGlnaHRcIj57c3RhdGUgfHwgXCJTVEFSVFwifTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2FjdGlvbiAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWJ1Zy1zdGF0LWJveFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdC1sYWJlbFwiPkFjdGlvbiBFeGVjdXRlZDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJhZGdlLXN1Y2Nlc3NcIj57YWN0aW9ufTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7dGltaW5ncyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGltaW5ncy1zZWN0aW9uXCI+XG4gICAgICAgICAgPGg0PkxhdGVuY3kgQnJlYWtkb3duPC9oND5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWluZ3MtZ3JpZFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aW1pbmctY2hpcFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aW1pbmctbGFiZWxcIj5TVFQgKFdoaXNwZXIpPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aW1pbmctdmFsdWVcIj57TWF0aC5yb3VuZCh0aW1pbmdzLnN0dF9tcyl9IG1zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWluZy1jaGlwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRpbWluZy1sYWJlbFwiPkJyYWluIChGU00gTkxVKTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGltaW5nLXZhbHVlIGhpZ2hsaWdodC1mYXN0XCI+e01hdGgucm91bmQodGltaW5ncy5icmFpbl9tcyl9IG1zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWluZy1jaGlwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRpbWluZy1sYWJlbFwiPlRUUyAoVm9pY2UpPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aW1pbmctdmFsdWVcIj57TWF0aC5yb3VuZCh0aW1pbmdzLnR0c19tcyl9IG1zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWluZy1jaGlwIHRpbWluZy10b3RhbFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aW1pbmctbGFiZWxcIj5Sb3VuZC1UcmlwIFRvdGFsPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aW1pbmctdmFsdWVcIj57TWF0aC5yb3VuZCh0aW1pbmdzLnRvdGFsX21zKX0gbXM8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNsb3RzLXNlY3Rpb25cIj5cbiAgICAgICAgPGg0PkV4dHJhY3RlZCBDb250ZXh0IFNsb3RzPC9oND5cbiAgICAgICAge3Nsb3RFbnRyaWVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJuby1kYXRhXCI+Tm8gc2xvdHMgcG9wdWxhdGVkIHlldC48L3A+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInNsb3RzLXRhYmxlXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGg+U2xvdDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPkV4dHJhY3RlZCBWYWx1ZTwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7c2xvdEVudHJpZXMubWFwKChbaywgdl0pID0+IChcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtrfT5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzbG90LWtleVwiPntrfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic2xvdC12YWxcIj57diAhPT0gbnVsbCAmJiB2ICE9PSB1bmRlZmluZWQgPyBTdHJpbmcodikgOiBcIuKAlFwifTwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXctdG9nZ2xlLXJvd1wiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UmF3KChwcmV2KSA9PiAhcHJldil9XG4gICAgICAgID5cbiAgICAgICAgICB7c2hvd1JhdyA/IFwiSGlkZSBSYXcgRnJhbWUgSlNPTlwiIDogXCJWaWV3IFJhdyBGcmFtZSBKU09OXCJ9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtzaG93UmF3ICYmIChcbiAgICAgICAgPHByZSBjbGFzc05hbWU9XCJyYXctanNvbi12aWV3ZXJcIj5cbiAgICAgICAgICB7SlNPTi5zdHJpbmdpZnkobGF0ZXN0VHVybiwgbnVsbCwgMil9XG4gICAgICAgIDwvcHJlPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuIl19