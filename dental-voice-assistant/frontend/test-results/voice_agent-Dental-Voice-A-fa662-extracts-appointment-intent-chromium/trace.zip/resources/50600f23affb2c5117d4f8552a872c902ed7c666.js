const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
export function useAudioPlayer() {
	const [isPlaying, setIsPlaying] = useState(false);
	const queueRef = useRef([]);
	const audioRef = useRef(null);
	const playNext = useCallback(() => {
		if (queueRef.current.length === 0) {
			setIsPlaying(false);
			return;
		}
		const item = queueRef.current.shift();
		if (!item || !item.data) {
			playNext();
			return;
		}
		try {
			const mime = item.mime || "audio/mpeg";
			const src = `data:${mime};base64,${item.data}`;
			const audio = new Audio(src);
			audioRef.current = audio;
			setIsPlaying(true);
			audio.onended = () => {
				setIsPlaying(false);
				playNext();
			};
			audio.onerror = (e) => {
				console.warn("Audio playback error:", e);
				setIsPlaying(false);
				playNext();
			};
			audio.play().catch((err) => {
				console.warn("Audio autoplay blocked or failed:", err);
				setIsPlaying(false);
				playNext();
			});
		} catch (e) {
			console.error("Failed to construct audio element:", e);
			setIsPlaying(false);
			playNext();
		}
	}, []);
	const enqueue = useCallback((base64Data, mimeType = "audio/mpeg") => {
		queueRef.current.push({
			data: base64Data,
			mime: mimeType
		});
		if (!isPlaying) {
			playNext();
		}
	}, [isPlaying, playNext]);
	const stop = useCallback(() => {
		queueRef.current = [];
		if (audioRef.current) {
			audioRef.current.pause();
			audioRef.current.currentTime = 0;
		}
		setIsPlaying(false);
	}, []);
	useEffect(() => {
		return () => {
			stop();
		};
	}, [stop]);
	return {
		enqueue,
		stop,
		isPlaying
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsVUFBVSxtQkFBbUI7QUFFekQsT0FBTyxTQUFTLGlCQUFpQjtDQUMvQixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sV0FBVyxPQUE4QyxDQUFDLENBQUM7Q0FDakUsTUFBTSxXQUFXLE9BQWdDLElBQUk7Q0FFckQsTUFBTSxXQUFXLGtCQUFrQjtFQUNqQyxJQUFJLFNBQVMsUUFBUSxXQUFXLEdBQUc7R0FDakMsYUFBYSxLQUFLO0dBQ2xCO0VBQ0Y7RUFFQSxNQUFNLE9BQU8sU0FBUyxRQUFRLE1BQU07RUFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLE1BQU07R0FDdkIsU0FBUztHQUNUO0VBQ0Y7RUFFQSxJQUFJO0dBQ0YsTUFBTSxPQUFPLEtBQUssUUFBUTtHQUMxQixNQUFNLE1BQU0sUUFBUSxLQUFLLFVBQVUsS0FBSztHQUN4QyxNQUFNLFFBQVEsSUFBSSxNQUFNLEdBQUc7R0FDM0IsU0FBUyxVQUFVO0dBQ25CLGFBQWEsSUFBSTtHQUVqQixNQUFNLGdCQUFnQjtJQUNwQixhQUFhLEtBQUs7SUFDbEIsU0FBUztHQUNYO0dBRUEsTUFBTSxXQUFXLE1BQU07SUFDckIsUUFBUSxLQUFLLHlCQUF5QixDQUFDO0lBQ3ZDLGFBQWEsS0FBSztJQUNsQixTQUFTO0dBQ1g7R0FFQSxNQUFNLEtBQUssQ0FBQyxDQUFDLE9BQU8sUUFBUTtJQUMxQixRQUFRLEtBQUsscUNBQXFDLEdBQUc7SUFDckQsYUFBYSxLQUFLO0lBQ2xCLFNBQVM7R0FDWCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLHNDQUFzQyxDQUFDO0dBQ3JELGFBQWEsS0FBSztHQUNsQixTQUFTO0VBQ1g7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sVUFBVSxhQUNiLFlBQW9CLFdBQVcsaUJBQWlCO0VBQy9DLFNBQVMsUUFBUSxLQUFLO0dBQUUsTUFBTTtHQUFZLE1BQU07RUFBUyxDQUFDO0VBQzFELElBQUksQ0FBQyxXQUFXO0dBQ2QsU0FBUztFQUNYO0NBQ0YsR0FDQSxDQUFDLFdBQVcsUUFBUSxDQUN0QjtDQUVBLE1BQU0sT0FBTyxrQkFBa0I7RUFDN0IsU0FBUyxVQUFVLENBQUM7RUFDcEIsSUFBSSxTQUFTLFNBQVM7R0FDcEIsU0FBUyxRQUFRLE1BQU07R0FDdkIsU0FBUyxRQUFRLGNBQWM7RUFDakM7RUFDQSxhQUFhLEtBQUs7Q0FDcEIsR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDZCxhQUFhO0dBQ1gsS0FBSztFQUNQO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULE9BQU87RUFBRTtFQUFTO0VBQU07Q0FBVTtBQUNwQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ1c2VBdWRpb1BsYXllci50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBdWRpb1BsYXllcigpIHtcbiAgY29uc3QgW2lzUGxheWluZywgc2V0SXNQbGF5aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgcXVldWVSZWYgPSB1c2VSZWY8QXJyYXk8eyBkYXRhOiBzdHJpbmc7IG1pbWU6IHN0cmluZyB9Pj4oW10pO1xuICBjb25zdCBhdWRpb1JlZiA9IHVzZVJlZjxIVE1MQXVkaW9FbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgcGxheU5leHQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHF1ZXVlUmVmLmN1cnJlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGl0ZW0gPSBxdWV1ZVJlZi5jdXJyZW50LnNoaWZ0KCk7XG4gICAgaWYgKCFpdGVtIHx8ICFpdGVtLmRhdGEpIHtcbiAgICAgIHBsYXlOZXh0KCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG1pbWUgPSBpdGVtLm1pbWUgfHwgXCJhdWRpby9tcGVnXCI7XG4gICAgICBjb25zdCBzcmMgPSBgZGF0YToke21pbWV9O2Jhc2U2NCwke2l0ZW0uZGF0YX1gO1xuICAgICAgY29uc3QgYXVkaW8gPSBuZXcgQXVkaW8oc3JjKTtcbiAgICAgIGF1ZGlvUmVmLmN1cnJlbnQgPSBhdWRpbztcbiAgICAgIHNldElzUGxheWluZyh0cnVlKTtcblxuICAgICAgYXVkaW8ub25lbmRlZCA9ICgpID0+IHtcbiAgICAgICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICAgICAgcGxheU5leHQoKTtcbiAgICAgIH07XG5cbiAgICAgIGF1ZGlvLm9uZXJyb3IgPSAoZSkgPT4ge1xuICAgICAgICBjb25zb2xlLndhcm4oXCJBdWRpbyBwbGF5YmFjayBlcnJvcjpcIiwgZSk7XG4gICAgICAgIHNldElzUGxheWluZyhmYWxzZSk7XG4gICAgICAgIHBsYXlOZXh0KCk7XG4gICAgICB9O1xuXG4gICAgICBhdWRpby5wbGF5KCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLndhcm4oXCJBdWRpbyBhdXRvcGxheSBibG9ja2VkIG9yIGZhaWxlZDpcIiwgZXJyKTtcbiAgICAgICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICAgICAgcGxheU5leHQoKTtcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY29uc3RydWN0IGF1ZGlvIGVsZW1lbnQ6XCIsIGUpO1xuICAgICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICAgIHBsYXlOZXh0KCk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgY29uc3QgZW5xdWV1ZSA9IHVzZUNhbGxiYWNrKFxuICAgIChiYXNlNjREYXRhOiBzdHJpbmcsIG1pbWVUeXBlID0gXCJhdWRpby9tcGVnXCIpID0+IHtcbiAgICAgIHF1ZXVlUmVmLmN1cnJlbnQucHVzaCh7IGRhdGE6IGJhc2U2NERhdGEsIG1pbWU6IG1pbWVUeXBlIH0pO1xuICAgICAgaWYgKCFpc1BsYXlpbmcpIHtcbiAgICAgICAgcGxheU5leHQoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtpc1BsYXlpbmcsIHBsYXlOZXh0XVxuICApO1xuXG4gIGNvbnN0IHN0b3AgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgcXVldWVSZWYuY3VycmVudCA9IFtdO1xuICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSB7XG4gICAgICBhdWRpb1JlZi5jdXJyZW50LnBhdXNlKCk7XG4gICAgICBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lID0gMDtcbiAgICB9XG4gICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHN0b3AoKTtcbiAgICB9O1xuICB9LCBbc3RvcF0pO1xuXG4gIHJldHVybiB7IGVucXVldWUsIHN0b3AsIGlzUGxheWluZyB9O1xufVxuIl19