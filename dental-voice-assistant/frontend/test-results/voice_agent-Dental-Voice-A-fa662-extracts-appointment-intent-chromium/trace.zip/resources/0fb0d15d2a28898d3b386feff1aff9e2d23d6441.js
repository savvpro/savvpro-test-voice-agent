import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Settings.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
import { getClinicInfo } from "/src/api/client.ts";
var _jsxFileName = "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/Settings.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4faeb0b1";
var _s = $RefreshSig$();
export function Settings() {
	_s();
	const [clinic, setClinic] = useState(null);
	useEffect(() => {
		getClinicInfo().then(setClinic).catch((err) => console.warn("Could not load clinic config:", err));
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "clinic-settings card",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-title-bar",
				children: /* @__PURE__ */ _jsxDEV("h3", { children: "ℹ️ Clinic Rules & Specs" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "clinic-info-list",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "info-item",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "info-key",
							children: "Clinic Name"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "info-val",
							children: clinic?.name || "BrightSmile Dental Clinic"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "info-item",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "info-key",
							children: "Hours"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "info-val",
							children: [
								clinic?.open_hour ?? 9,
								":00 AM – ",
								clinic?.close_hour ?? 17,
								":00 PM"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "info-item",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "info-key",
							children: "Days"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "info-val",
							children: "Monday – Saturday (Closed Sunday)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "info-item",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "info-key",
							children: "Slot Length"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "info-val",
							children: [clinic?.slot_minutes ?? 30, " minutes"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "services-section",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "services-title",
					children: "Covered Services:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "services-tags",
					children: (clinic?.services || [
						"cleaning",
						"checkup",
						"filling",
						"whitening",
						"root canal",
						"braces consultation"
					]).map((s) => /* @__PURE__ */ _jsxDEV("span", {
						className: "service-pill",
						children: s
					}, s, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "tech-stack-row",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "tech-badge",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "tech-badge-dot green" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "STT: Faster-Whisper" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "tech-badge",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "tech-badge-dot purple" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Brain: Rule-Based FSM (Zero LLM)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "tech-badge",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "tech-badge-dot blue" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "TTS: EdgeTTS" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_s(Settings, "k1e4SNTMoH76RbAPbmSo0Tq9k6w=");
_c = Settings;
var _c;
$RefreshReg$(_c, "Settings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Settings.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/Settings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/Settings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/Settings.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHFCQUFxQjs7OztBQUc5QixPQUFPLFNBQVMsV0FBVzs7Q0FDekIsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUE0QixJQUFJO0NBRTVELGdCQUFnQjtFQUNkLGNBQWMsQ0FBQyxDQUNaLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTyxRQUFRLFFBQVEsS0FBSyxpQ0FBaUMsR0FBRyxDQUFDO0NBQ3RFLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxNQUFELFlBQUksMEJBQTJCOzs7OztHQUM1Qjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVztNQUFpQjs7OztnQkFDNUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVksUUFBUSxRQUFRO01BQWtDOzs7O2NBQzNFOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXO01BQVc7Ozs7Z0JBQ3RDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQjtRQUNHLFFBQVEsYUFBYTtRQUFFO1FBQVUsUUFBUSxjQUFjO1FBQUc7T0FDdkQ7Ozs7O2NBQ0g7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBVTs7OztnQkFDckMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBdUM7Ozs7Y0FDL0Q7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBaUI7Ozs7Z0JBQzVDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUE0QixRQUFRLGdCQUFnQixJQUFHLFVBQWM7Ozs7O2NBQ2xFOzs7Ozs7SUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWlCO0lBQXVCOzs7O2NBQ3hELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2dCQUNYLFFBQVEsWUFBWTtNQUNwQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7S0FDRixFQUFDLENBQUUsS0FBSyxNQUNOLHdCQUFDLFFBQUQ7TUFBYyxXQUFVO2dCQUNyQjtLQUNHLEdBRks7Ozs7WUFFTCxDQUNQO0lBQ0U7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUJBQXdCOzs7O2dCQUN4Qyx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2NBQzVCOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdCQUF5Qjs7OztnQkFDekMsd0JBQUMsUUFBRCxZQUFNLG1DQUFzQzs7OztjQUN6Qzs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxzQkFBdUI7Ozs7Z0JBQ3ZDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztjQUNyQjs7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXR0aW5ncy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZ2V0Q2xpbmljSW5mbyB9IGZyb20gXCIuLi9hcGkvY2xpZW50XCI7XG5pbXBvcnQgdHlwZSB7IENsaW5pY0luZm8gfSBmcm9tIFwiLi4vdHlwZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFNldHRpbmdzKCkge1xuICBjb25zdCBbY2xpbmljLCBzZXRDbGluaWNdID0gdXNlU3RhdGU8Q2xpbmljSW5mbyB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZ2V0Q2xpbmljSW5mbygpXG4gICAgICAudGhlbihzZXRDbGluaWMpXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS53YXJuKFwiQ291bGQgbm90IGxvYWQgY2xpbmljIGNvbmZpZzpcIiwgZXJyKSk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xpbmljLXNldHRpbmdzIGNhcmRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWwtdGl0bGUtYmFyXCI+XG4gICAgICAgIDxoMz7ihLnvuI8gQ2xpbmljIFJ1bGVzICYgU3BlY3M8L2gzPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xpbmljLWluZm8tbGlzdFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8taXRlbVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImluZm8ta2V5XCI+Q2xpbmljIE5hbWU8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5mby12YWxcIj57Y2xpbmljPy5uYW1lIHx8IFwiQnJpZ2h0U21pbGUgRGVudGFsIENsaW5pY1wifTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLWl0ZW1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmZvLWtleVwiPkhvdXJzPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImluZm8tdmFsXCI+XG4gICAgICAgICAgICB7Y2xpbmljPy5vcGVuX2hvdXIgPz8gOX06MDAgQU0g4oCTIHtjbGluaWM/LmNsb3NlX2hvdXIgPz8gMTd9OjAwIFBNXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8taXRlbVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImluZm8ta2V5XCI+RGF5czwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmZvLXZhbFwiPk1vbmRheSDigJMgU2F0dXJkYXkgKENsb3NlZCBTdW5kYXkpPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8taXRlbVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImluZm8ta2V5XCI+U2xvdCBMZW5ndGg8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5mby12YWxcIj57Y2xpbmljPy5zbG90X21pbnV0ZXMgPz8gMzB9IG1pbnV0ZXM8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VydmljZXMtc2VjdGlvblwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZXJ2aWNlcy10aXRsZVwiPkNvdmVyZWQgU2VydmljZXM6PC9zcGFuPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2VzLXRhZ3NcIj5cbiAgICAgICAgICB7KGNsaW5pYz8uc2VydmljZXMgfHwgW1xuICAgICAgICAgICAgXCJjbGVhbmluZ1wiLFxuICAgICAgICAgICAgXCJjaGVja3VwXCIsXG4gICAgICAgICAgICBcImZpbGxpbmdcIixcbiAgICAgICAgICAgIFwid2hpdGVuaW5nXCIsXG4gICAgICAgICAgICBcInJvb3QgY2FuYWxcIixcbiAgICAgICAgICAgIFwiYnJhY2VzIGNvbnN1bHRhdGlvblwiLFxuICAgICAgICAgIF0pLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXtzfSBjbGFzc05hbWU9XCJzZXJ2aWNlLXBpbGxcIj5cbiAgICAgICAgICAgICAge3N9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGVjaC1zdGFjay1yb3dcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZWNoLWJhZGdlXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGVjaC1iYWRnZS1kb3QgZ3JlZW5cIiAvPlxuICAgICAgICAgIDxzcGFuPlNUVDogRmFzdGVyLVdoaXNwZXI8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRlY2gtYmFkZ2VcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZWNoLWJhZGdlLWRvdCBwdXJwbGVcIiAvPlxuICAgICAgICAgIDxzcGFuPkJyYWluOiBSdWxlLUJhc2VkIEZTTSAoWmVybyBMTE0pPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZWNoLWJhZGdlXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGVjaC1iYWRnZS1kb3QgYmx1ZVwiIC8+XG4gICAgICAgICAgPHNwYW4+VFRTOiBFZGdlVFRTPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4iXX0=