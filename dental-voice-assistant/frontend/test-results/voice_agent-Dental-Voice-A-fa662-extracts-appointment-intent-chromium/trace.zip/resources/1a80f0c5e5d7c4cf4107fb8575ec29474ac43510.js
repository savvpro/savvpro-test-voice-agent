import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];// d:\Importance\savvpro-test-voice-agent\dental-voice-assistant\frontend\src\App.tsx
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
import "/src/App.css";
import { CallPanel } from "/src/components/CallPanel.tsx?t=1793812752729";
import { DebugPanel } from "/src/components/DebugPanel.tsx";
import { AppointmentsPanel } from "/src/components/AppointmentsPanel.tsx";
import { Settings } from "/src/components/Settings.tsx";
import { useCall } from "/src/hooks/useCall.ts";
import { useRecorder } from "/src/hooks/useRecorder.ts?t=1793812753758";
import { useAudioPlayer } from "/src/hooks/useAudioPlayer.ts";
var _jsxFileName = "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/App.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4faeb0b1";
var _s = $RefreshSig$();
export function App() {
	_s();
	const { enqueue: playAudio, isPlaying: isPlayingAudio } = useAudioPlayer();
	const [latestCompletedTurn, setLatestCompletedTurn] = useState(null);
	const handleAudioReceived = useCallback((base64Data, mime) => {
		playAudio(base64Data, mime);
	}, [playAudio]);
	const handleTurnComplete = useCallback((turn) => {
		setLatestCompletedTurn(turn);
	}, []);
	const { status, transcript, latestTurn, error, startCall, endCall, sendText, sendAudio } = useCall(handleAudioReceived, handleTurnComplete);
	// Stream audio chunks directly to the backend as they are recorded.
	const { isRecording, error: micError, start: startRecording, stop: stopRecording } = useRecorder(sendAudio);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "app-header",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "header-brand",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "brand-logo",
					children: "🦷"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", { children: "BrightSmile Dental Clinic" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "header-tagline",
					children: "AI Telephony Voice Agent — Telephony Booking, Rescheduling & Cancellation"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "header-meta",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "badge-pill",
					children: "FSM Rule-Based Brain"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "badge-pill highlight",
					children: "Sub-Second NLU"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "app-main",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "main-left",
				children: /* @__PURE__ */ _jsxDEV(CallPanel, {
					status,
					transcript,
					isRecording,
					isPlayingAudio,
					error: error || micError,
					startCall,
					endCall,
					sendText,
					startRecording,
					stopRecording
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "main-right",
				children: [
					/* @__PURE__ */ _jsxDEV(DebugPanel, { latestTurn: latestTurn || latestCompletedTurn }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AppointmentsPanel, { latestTurn: latestTurn || latestCompletedTurn }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Settings, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_s(App, "NGVu2/E5KlHAHIN/jH0RrJwUnfI=", false, function() {
	return [
		useAudioPlayer,
		useCall,
		useRecorder
	];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx?t=1793812753758";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUNBLFNBQVMsYUFBYSxnQkFBZ0I7QUFDdEMsT0FBTztBQUNQLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHNCQUFzQjs7OztBQUcvQixPQUFPLFNBQVMsTUFBTTs7Q0FDcEIsTUFBTSxFQUFFLFNBQVMsV0FBVyxXQUFXLG1CQUFtQixlQUFlO0NBQ3pFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQTZCLElBQUk7Q0FFdkYsTUFBTSxzQkFBc0IsYUFDekIsWUFBb0IsU0FBaUI7RUFDcEMsVUFBVSxZQUFZLElBQUk7Q0FDNUIsR0FDQSxDQUFDLFNBQVMsQ0FDWjtDQUVBLE1BQU0scUJBQXFCLGFBQWEsU0FBc0I7RUFDNUQsdUJBQXVCLElBQUk7Q0FDN0IsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLEVBQ0osUUFDQSxZQUNBLFlBQ0EsT0FDQSxXQUNBLFNBQ0EsVUFDQSxjQUNFLFFBQVEscUJBQXFCLGtCQUFrQjs7Q0FHbkQsTUFBTSxFQUFFLGFBQWEsT0FBTyxVQUFVLE9BQU8sZ0JBQWdCLE1BQU0sa0JBQ2pFLFlBQVksU0FBUztDQUV2QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUFsQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhO0lBQVE7Ozs7Y0FDckMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSw0QkFBNkI7Ozs7Y0FDakMsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaUI7SUFFM0I7Ozs7WUFDSDs7OztZQUNGOzs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhO0lBQTBCOzs7O2NBQ3ZELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXVCO0lBQW9COzs7O1lBQ3hEOzs7OztXQUNDOzs7OztZQUVSLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxXQUFEO0tBQ1U7S0FDSTtLQUNDO0tBQ0c7S0FDaEIsT0FBTyxTQUFTO0tBQ0w7S0FDRjtLQUNDO0tBQ007S0FDRDtJQUNoQjs7Ozs7R0FDRTs7OzthQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxZQUFELEVBQVksWUFBWSxjQUFjLG9CQUFzQjs7Ozs7S0FDNUQsd0JBQUMsbUJBQUQsRUFBbUIsWUFBWSxjQUFjLG9CQUFzQjs7Ozs7S0FDbkUsd0JBQUMsVUFBRCxDQUFXOzs7OztJQUNSOzs7OztXQUNEOzs7OztVQUNIOzs7Ozs7QUFFVDs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8vIGQ6XFxJbXBvcnRhbmNlXFxzYXZ2cHJvLXRlc3Qtdm9pY2UtYWdlbnRcXGRlbnRhbC12b2ljZS1hc3Npc3RhbnRcXGZyb250ZW5kXFxzcmNcXEFwcC50c3hcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5pbXBvcnQgeyBDYWxsUGFuZWwgfSBmcm9tIFwiLi9jb21wb25lbnRzL0NhbGxQYW5lbFwiO1xuaW1wb3J0IHsgRGVidWdQYW5lbCB9IGZyb20gXCIuL2NvbXBvbmVudHMvRGVidWdQYW5lbFwiO1xuaW1wb3J0IHsgQXBwb2ludG1lbnRzUGFuZWwgfSBmcm9tIFwiLi9jb21wb25lbnRzL0FwcG9pbnRtZW50c1BhbmVsXCI7XG5pbXBvcnQgeyBTZXR0aW5ncyB9IGZyb20gXCIuL2NvbXBvbmVudHMvU2V0dGluZ3NcIjtcbmltcG9ydCB7IHVzZUNhbGwgfSBmcm9tIFwiLi9ob29rcy91c2VDYWxsXCI7XG5pbXBvcnQgeyB1c2VSZWNvcmRlciB9IGZyb20gXCIuL2hvb2tzL3VzZVJlY29yZGVyXCI7XG5pbXBvcnQgeyB1c2VBdWRpb1BsYXllciB9IGZyb20gXCIuL2hvb2tzL3VzZUF1ZGlvUGxheWVyXCI7XG5pbXBvcnQgdHlwZSB7IFR1cm5NZXNzYWdlIH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgeyBlbnF1ZXVlOiBwbGF5QXVkaW8sIGlzUGxheWluZzogaXNQbGF5aW5nQXVkaW8gfSA9IHVzZUF1ZGlvUGxheWVyKCk7XG4gIGNvbnN0IFtsYXRlc3RDb21wbGV0ZWRUdXJuLCBzZXRMYXRlc3RDb21wbGV0ZWRUdXJuXSA9IHVzZVN0YXRlPFR1cm5NZXNzYWdlIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgaGFuZGxlQXVkaW9SZWNlaXZlZCA9IHVzZUNhbGxiYWNrKFxuICAgIChiYXNlNjREYXRhOiBzdHJpbmcsIG1pbWU6IHN0cmluZykgPT4ge1xuICAgICAgcGxheUF1ZGlvKGJhc2U2NERhdGEsIG1pbWUpO1xuICAgIH0sXG4gICAgW3BsYXlBdWRpb11cbiAgKTtcblxuICBjb25zdCBoYW5kbGVUdXJuQ29tcGxldGUgPSB1c2VDYWxsYmFjaygodHVybjogVHVybk1lc3NhZ2UpID0+IHtcbiAgICBzZXRMYXRlc3RDb21wbGV0ZWRUdXJuKHR1cm4pO1xuICB9LCBbXSk7XG5cbiAgY29uc3Qge1xuICAgIHN0YXR1cyxcbiAgICB0cmFuc2NyaXB0LFxuICAgIGxhdGVzdFR1cm4sXG4gICAgZXJyb3IsXG4gICAgc3RhcnRDYWxsLFxuICAgIGVuZENhbGwsXG4gICAgc2VuZFRleHQsXG4gICAgc2VuZEF1ZGlvLFxuICB9ID0gdXNlQ2FsbChoYW5kbGVBdWRpb1JlY2VpdmVkLCBoYW5kbGVUdXJuQ29tcGxldGUpO1xuXG4gIC8vIFN0cmVhbSBhdWRpbyBjaHVua3MgZGlyZWN0bHkgdG8gdGhlIGJhY2tlbmQgYXMgdGhleSBhcmUgcmVjb3JkZWQuXG4gIGNvbnN0IHsgaXNSZWNvcmRpbmcsIGVycm9yOiBtaWNFcnJvciwgc3RhcnQ6IHN0YXJ0UmVjb3JkaW5nLCBzdG9wOiBzdG9wUmVjb3JkaW5nIH0gPVxuICAgIHVzZVJlY29yZGVyKHNlbmRBdWRpbyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1zaGVsbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJhcHAtaGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLWJyYW5kXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnJhbmQtbG9nb1wiPvCfprc8L3NwYW4+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMT5CcmlnaHRTbWlsZSBEZW50YWwgQ2xpbmljPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhlYWRlci10YWdsaW5lXCI+XG4gICAgICAgICAgICAgIEFJIFRlbGVwaG9ueSBWb2ljZSBBZ2VudCDigJQgVGVsZXBob255IEJvb2tpbmcsIFJlc2NoZWR1bGluZyAmYW1wOyBDYW5jZWxsYXRpb25cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLW1ldGFcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZS1waWxsXCI+RlNNIFJ1bGUtQmFzZWQgQnJhaW48L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UtcGlsbCBoaWdobGlnaHRcIj5TdWItU2Vjb25kIE5MVTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiYXBwLW1haW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYWluLWxlZnRcIj5cbiAgICAgICAgICA8Q2FsbFBhbmVsXG4gICAgICAgICAgICBzdGF0dXM9e3N0YXR1c31cbiAgICAgICAgICAgIHRyYW5zY3JpcHQ9e3RyYW5zY3JpcHR9XG4gICAgICAgICAgICBpc1JlY29yZGluZz17aXNSZWNvcmRpbmd9XG4gICAgICAgICAgICBpc1BsYXlpbmdBdWRpbz17aXNQbGF5aW5nQXVkaW99XG4gICAgICAgICAgICBlcnJvcj17ZXJyb3IgfHwgbWljRXJyb3J9XG4gICAgICAgICAgICBzdGFydENhbGw9e3N0YXJ0Q2FsbH1cbiAgICAgICAgICAgIGVuZENhbGw9e2VuZENhbGx9XG4gICAgICAgICAgICBzZW5kVGV4dD17c2VuZFRleHR9XG4gICAgICAgICAgICBzdGFydFJlY29yZGluZz17c3RhcnRSZWNvcmRpbmd9XG4gICAgICAgICAgICBzdG9wUmVjb3JkaW5nPXtzdG9wUmVjb3JkaW5nfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFpbi1yaWdodFwiPlxuICAgICAgICAgIDxEZWJ1Z1BhbmVsIGxhdGVzdFR1cm49e2xhdGVzdFR1cm4gfHwgbGF0ZXN0Q29tcGxldGVkVHVybn0gLz5cbiAgICAgICAgICA8QXBwb2ludG1lbnRzUGFuZWwgbGF0ZXN0VHVybj17bGF0ZXN0VHVybiB8fCBsYXRlc3RDb21wbGV0ZWRUdXJufSAvPlxuICAgICAgICAgIDxTZXR0aW5ncyAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdfQ==