import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppointmentsPanel.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
import { getAppointments } from "/src/api/client.ts";
var _jsxFileName = "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/AppointmentsPanel.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4faeb0b1";
var _s = $RefreshSig$();
export function AppointmentsPanel({ latestTurn }) {
	_s();
	const [selectedDate, setSelectedDate] = useState(() => {
		return new Date().toISOString().slice(0, 10);
	});
	const [appointments, setAppointments] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const fetchSchedule = useCallback(async (dateStr) => {
		setLoading(true);
		setError(null);
		try {
			const data = await getAppointments(dateStr);
			setAppointments(data);
		} catch (err) {
			console.warn("Failed to load appointments:", err);
			setError("Could not load clinic appointments.");
		} finally {
			setLoading(false);
		}
	}, []);
	// Fetch when selectedDate changes
	useEffect(() => {
		fetchSchedule(selectedDate);
	}, [selectedDate, fetchSchedule]);
	// Refresh if an action (booked, cancelled, rescheduled) was executed
	useEffect(() => {
		if (latestTurn?.action) {
			fetchSchedule(selectedDate);
		}
	}, [
		latestTurn?.action,
		selectedDate,
		fetchSchedule
	]);
	const handleDateShift = (offsetDays) => {
		const d = new Date(selectedDate);
		d.setDate(d.getDate() + offsetDays);
		setSelectedDate(d.toISOString().slice(0, 10));
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "appointments-panel card",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-title-bar",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: "📅 Clinic Appointments" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "subtitle",
					children: "Live database schedule for BrightSmile Dental"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn btn-icon-only",
					onClick: () => fetchSchedule(selectedDate),
					title: "Refresh appointments",
					disabled: loading,
					children: "🔄"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "date-picker-row",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn btn-sm btn-outline",
						onClick: () => handleDateShift(-1),
						children: "◀ Prev Day"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "date",
						className: "date-input",
						value: selectedDate,
						onChange: (e) => setSelectedDate(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn btn-sm btn-outline",
						onClick: () => handleDateShift(1),
						children: "Next Day ▶"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn btn-sm btn-secondary",
						onClick: () => setSelectedDate(new Date().toISOString().slice(0, 10)),
						children: "Today"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "error-banner",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "appointments-list-wrapper",
				children: loading ? /* @__PURE__ */ _jsxDEV("div", {
					className: "loading-state",
					children: "Loading appointments..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 11
				}, this) : appointments.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "empty-appointments",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "calendar-icon",
						children: "🗓️"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "No appointments booked for this date." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("table", {
					className: "appointments-table",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Time" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Patient" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Phone" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Service" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Status" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: appointments.map((appt) => /* @__PURE__ */ _jsxDEV("tr", {
						className: `status-row-${appt.status}`,
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								className: "time-col",
								children: [
									appt.start_time.slice(0, 5),
									" - ",
									appt.end_time.slice(0, 5)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "patient-col font-semibold",
								children: appt.patient_name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "phone-col font-mono text-muted",
								children: appt.patient_phone
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "service-col",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "service-badge",
									children: appt.service
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "status-col",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: `status-tag status-${appt.status}`,
									children: appt.status
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 19
							}, this)
						]
					}, appt.id, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 17
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 5
	}, this);
}
_s(AppointmentsPanel, "e4B+D78QJ5ShviOf0X5/mOLwmYc=");
_c = AppointmentsPanel;
var _c;
$RefreshReg$(_c, "AppointmentsPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AppointmentsPanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/AppointmentsPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/AppointmentsPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/AppointmentsPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFVBQVUsbUJBQW1CO0FBQ2pELFNBQVMsdUJBQXVCOzs7O0FBT2hDLE9BQU8sU0FBUyxrQkFBa0IsRUFBRSxjQUFzQzs7Q0FDeEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLGVBQXVCO0VBQzdELE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRTtDQUM3QyxDQUFDO0NBQ0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLENBQUMsQ0FBQztDQUNsRSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXdCLElBQUk7Q0FFdEQsTUFBTSxnQkFBZ0IsWUFBWSxPQUFPLFlBQW9CO0VBQzNELFdBQVcsSUFBSTtFQUNmLFNBQVMsSUFBSTtFQUNiLElBQUk7R0FDRixNQUFNLE9BQU8sTUFBTSxnQkFBZ0IsT0FBTztHQUMxQyxnQkFBZ0IsSUFBSTtFQUN0QixTQUFTLEtBQVU7R0FDakIsUUFBUSxLQUFLLGdDQUFnQyxHQUFHO0dBQ2hELFNBQVMscUNBQXFDO0VBQ2hELFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRixHQUFHLENBQUMsQ0FBQzs7Q0FHTCxnQkFBZ0I7RUFDZCxjQUFjLFlBQVk7Q0FDNUIsR0FBRyxDQUFDLGNBQWMsYUFBYSxDQUFDOztDQUdoQyxnQkFBZ0I7RUFDZCxJQUFJLFlBQVksUUFBUTtHQUN0QixjQUFjLFlBQVk7RUFDNUI7Q0FDRixHQUFHO0VBQUMsWUFBWTtFQUFRO0VBQWM7Q0FBYSxDQUFDO0NBRXBELE1BQU0sbUJBQW1CLGVBQXVCO0VBQzlDLE1BQU0sSUFBSSxJQUFJLEtBQUssWUFBWTtFQUMvQixFQUFFLFFBQVEsRUFBRSxRQUFRLElBQUksVUFBVTtFQUNsQyxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0NBQzlDO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUkseUJBQTBCOzs7O2NBQzlCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVc7SUFBZ0Q7Ozs7WUFDckU7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixlQUFlLGNBQWMsWUFBWTtLQUN6QyxPQUFNO0tBQ04sVUFBVTtlQUNYO0lBRU87Ozs7WUFDTDs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtNQUNWLGVBQWUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDbEM7S0FFTzs7Ozs7S0FFUix3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixPQUFPO01BQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztLQUNoRDs7Ozs7S0FFRCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixlQUFlLGdCQUFnQixDQUFDO2dCQUNqQztLQUVPOzs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtNQUNWLGVBQWUsZ0JBQWdCLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztnQkFDckU7S0FFTzs7Ozs7SUFDTDs7Ozs7O0dBRUosU0FBUyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFnQjtHQUFXOzs7OztHQUVwRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFVBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZ0I7SUFBNEI7Ozs7ZUFDekQsYUFBYSxXQUFXLElBQzFCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0I7S0FBUzs7OztlQUN6Qyx3QkFBQyxLQUFELFlBQUcsd0NBQXdDOzs7O2FBQ3hDOzs7OztlQUVMLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7TUFDRSx3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7TUFDWix3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksUUFBUzs7Ozs7TUFDYix3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksU0FBVTs7Ozs7S0FDWjs7OztjQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRCxZQUNHLGFBQWEsS0FBSyxTQUNqQix3QkFBQyxNQUFEO01BQWtCLFdBQVcsY0FBYyxLQUFLO2dCQUFoRDtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0csS0FBSyxXQUFXLE1BQU0sR0FBRyxDQUFDO1NBQUU7U0FBSSxLQUFLLFNBQVMsTUFBTSxHQUFHLENBQUM7UUFDdkQ7Ozs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE2QixLQUFLO09BQWlCOzs7OztPQUNqRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBa0MsS0FBSztPQUFrQjs7Ozs7T0FDdkUsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCLEtBQUs7UUFBYzs7Ozs7T0FDbEQ7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1osd0JBQUMsUUFBRDtTQUFNLFdBQVcscUJBQXFCLEtBQUs7bUJBQ3hDLEtBQUs7UUFDRjs7Ozs7T0FDSjs7Ozs7TUFDRjtRQWRLLEtBQUs7Ozs7WUFjVixDQUNMLEVBQ0k7Ozs7YUFDRjs7Ozs7O0dBRU47Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcG9pbnRtZW50c1BhbmVsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZ2V0QXBwb2ludG1lbnRzIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRcIjtcbmltcG9ydCB0eXBlIHsgQXBwb2ludG1lbnQsIFR1cm5NZXNzYWdlIH0gZnJvbSBcIi4uL3R5cGVzXCI7XG5cbmludGVyZmFjZSBBcHBvaW50bWVudHNQYW5lbFByb3BzIHtcbiAgbGF0ZXN0VHVybjogVHVybk1lc3NhZ2UgfCBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQXBwb2ludG1lbnRzUGFuZWwoeyBsYXRlc3RUdXJuIH06IEFwcG9pbnRtZW50c1BhbmVsUHJvcHMpIHtcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlPHN0cmluZz4oKCkgPT4ge1xuICAgIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICB9KTtcbiAgY29uc3QgW2FwcG9pbnRtZW50cywgc2V0QXBwb2ludG1lbnRzXSA9IHVzZVN0YXRlPEFwcG9pbnRtZW50W10+KFtdKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGZldGNoU2NoZWR1bGUgPSB1c2VDYWxsYmFjayhhc3luYyAoZGF0ZVN0cjogc3RyaW5nKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldEFwcG9pbnRtZW50cyhkYXRlU3RyKTtcbiAgICAgIHNldEFwcG9pbnRtZW50cyhkYXRhKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgY29uc29sZS53YXJuKFwiRmFpbGVkIHRvIGxvYWQgYXBwb2ludG1lbnRzOlwiLCBlcnIpO1xuICAgICAgc2V0RXJyb3IoXCJDb3VsZCBub3QgbG9hZCBjbGluaWMgYXBwb2ludG1lbnRzLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLy8gRmV0Y2ggd2hlbiBzZWxlY3RlZERhdGUgY2hhbmdlc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZldGNoU2NoZWR1bGUoc2VsZWN0ZWREYXRlKTtcbiAgfSwgW3NlbGVjdGVkRGF0ZSwgZmV0Y2hTY2hlZHVsZV0pO1xuXG4gIC8vIFJlZnJlc2ggaWYgYW4gYWN0aW9uIChib29rZWQsIGNhbmNlbGxlZCwgcmVzY2hlZHVsZWQpIHdhcyBleGVjdXRlZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChsYXRlc3RUdXJuPy5hY3Rpb24pIHtcbiAgICAgIGZldGNoU2NoZWR1bGUoc2VsZWN0ZWREYXRlKTtcbiAgICB9XG4gIH0sIFtsYXRlc3RUdXJuPy5hY3Rpb24sIHNlbGVjdGVkRGF0ZSwgZmV0Y2hTY2hlZHVsZV0pO1xuXG4gIGNvbnN0IGhhbmRsZURhdGVTaGlmdCA9IChvZmZzZXREYXlzOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBkID0gbmV3IERhdGUoc2VsZWN0ZWREYXRlKTtcbiAgICBkLnNldERhdGUoZC5nZXREYXRlKCkgKyBvZmZzZXREYXlzKTtcbiAgICBzZXRTZWxlY3RlZERhdGUoZC50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcG9pbnRtZW50cy1wYW5lbCBjYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLXRpdGxlLWJhclwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMz7wn5OFIENsaW5pYyBBcHBvaW50bWVudHM8L2gzPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInN1YnRpdGxlXCI+TGl2ZSBkYXRhYmFzZSBzY2hlZHVsZSBmb3IgQnJpZ2h0U21pbGUgRGVudGFsPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4taWNvbi1vbmx5XCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaFNjaGVkdWxlKHNlbGVjdGVkRGF0ZSl9XG4gICAgICAgICAgdGl0bGU9XCJSZWZyZXNoIGFwcG9pbnRtZW50c1wiXG4gICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgID5cbiAgICAgICAgICDwn5SEXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGF0ZS1waWNrZXItcm93XCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLXNtIGJ0bi1vdXRsaW5lXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEYXRlU2hpZnQoLTEpfVxuICAgICAgICA+XG4gICAgICAgICAg4peAIFByZXYgRGF5XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJkYXRlLWlucHV0XCJcbiAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgLz5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zbSBidG4tb3V0bGluZVwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGF0ZVNoaWZ0KDEpfVxuICAgICAgICA+XG4gICAgICAgICAgTmV4dCBEYXkg4pa2XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLXNtIGJ0bi1zZWNvbmRhcnlcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRGF0ZShuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApKX1cbiAgICAgICAgPlxuICAgICAgICAgIFRvZGF5XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImVycm9yLWJhbm5lclwiPntlcnJvcn08L2Rpdj59XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwb2ludG1lbnRzLWxpc3Qtd3JhcHBlclwiPlxuICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctc3RhdGVcIj5Mb2FkaW5nIGFwcG9pbnRtZW50cy4uLjwvZGl2PlxuICAgICAgICApIDogYXBwb2ludG1lbnRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LWFwcG9pbnRtZW50c1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FsZW5kYXItaWNvblwiPvCfl5PvuI88L3NwYW4+XG4gICAgICAgICAgICA8cD5ObyBhcHBvaW50bWVudHMgYm9va2VkIGZvciB0aGlzIGRhdGUuPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJhcHBvaW50bWVudHMtdGFibGVcIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aD5UaW1lPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+UGF0aWVudDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPlBob25lPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+U2VydmljZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7YXBwb2ludG1lbnRzLm1hcCgoYXBwdCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e2FwcHQuaWR9IGNsYXNzTmFtZT17YHN0YXR1cy1yb3ctJHthcHB0LnN0YXR1c31gfT5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJ0aW1lLWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICB7YXBwdC5zdGFydF90aW1lLnNsaWNlKDAsIDUpfSAtIHthcHB0LmVuZF90aW1lLnNsaWNlKDAsIDUpfVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwYXRpZW50LWNvbCBmb250LXNlbWlib2xkXCI+e2FwcHQucGF0aWVudF9uYW1lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicGhvbmUtY29sIGZvbnQtbW9ubyB0ZXh0LW11dGVkXCI+e2FwcHQucGF0aWVudF9waG9uZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInNlcnZpY2UtY29sXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlcnZpY2UtYmFkZ2VcIj57YXBwdC5zZXJ2aWNlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic3RhdHVzLWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BzdGF0dXMtdGFnIHN0YXR1cy0ke2FwcHQuc3RhdHVzfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHthcHB0LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4iXX0=