const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
export function useCall(onAudioReceived, onTurnComplete) {
	const [status, setStatus] = useState("idle");
	const [transcript, setTranscript] = useState([]);
	const [latestTurn, setLatestTurn] = useState(null);
	const [error, setError] = useState(null);
	const wsRef = useRef(null);
	const startCall = useCallback(() => {
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
			return;
		}
		setStatus("connecting");
		setError(null);
		setTranscript([]);
		setLatestTurn(null);
		const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
		const host = window.location.host;
		// If running with Vite dev server (port 5173), Vite proxy routes /ws to backend ws://localhost:8000
		const wsUrl = `${protocol}//${host}/ws/calls`;
		const ws = new WebSocket(wsUrl);
		wsRef.current = ws;
		ws.onopen = () => {
			setStatus("connected");
		};
		ws.onmessage = (event) => {
			try {
				const msg = JSON.parse(event.data);
				if (msg.type === "turn") {
					setLatestTurn(msg);
					// Add user text if it was transcribed or echoed
					if (msg.user_text && msg.user_text.trim()) {
						setTranscript((prev) => [...prev, {
							id: `u-${msg.turn}-${Date.now()}`,
							turn: msg.turn,
							speaker: "user",
							text: msg.user_text,
							timestamp: new Date().toLocaleTimeString()
						}]);
					}
					// Add assistant reply
					if (msg.reply_text) {
						setTranscript((prev) => [...prev, {
							id: `a-${msg.turn}-${Date.now()}`,
							turn: msg.turn,
							speaker: "assistant",
							text: msg.reply_text,
							timestamp: new Date().toLocaleTimeString(),
							timings: msg.timings,
							state: msg.state
						}]);
					}
					// Enqueue audio
					if (msg.audio) {
						onAudioReceived?.(msg.audio, msg.audio_mime || "audio/mpeg");
					}
					onTurnComplete?.(msg);
					if (msg.end_call) {
						setStatus("idle");
					}
				} else if (msg.type === "call_ended") {
					setStatus("idle");
				} else if (msg.type === "error") {
					setError(`${msg.error}: ${msg.detail}`);
				}
			} catch (err) {
				console.error("Failed to parse WebSocket JSON message:", err);
			}
		};
		ws.onerror = (e) => {
			console.warn("WebSocket error:", e);
			setError("WebSocket connection failed. Ensure the backend server is running on port 8000.");
			setStatus("idle");
		};
		ws.onclose = () => {
			setStatus("idle");
			wsRef.current = null;
		};
	}, [onAudioReceived, onTurnComplete]);
	const endCall = useCallback(() => {
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
			try {
				wsRef.current.send(JSON.stringify({ type: "end" }));
			} catch (e) {
				console.warn("Failed to send end frame:", e);
			}
			wsRef.current.close(1e3, "user_hangup");
		}
		setStatus("idle");
		wsRef.current = null;
	}, []);
	const sendText = useCallback((text) => {
		if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
			setError("Call is not connected.");
			return;
		}
		const trimmed = text.trim();
		if (!trimmed) return;
		// Send JSON frame
		wsRef.current.send(JSON.stringify({
			type: "user_text",
			text: trimmed
		}));
	}, []);
	const sendAudio = useCallback(async (audioData) => {
		if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
			setError("Call is not connected.");
			return;
		}
		try {
			if (audioData instanceof Blob) {
				const buffer = await audioData.arrayBuffer();
				wsRef.current.send(buffer);
			} else {
				wsRef.current.send(audioData);
			}
		} catch (err) {
			console.error("Failed to send audio bytes:", err);
			setError("Failed to stream audio frame to server.");
		}
	}, []);
	useEffect(() => {
		return () => {
			if (wsRef.current) {
				wsRef.current.close();
			}
		};
	}, []);
	return {
		status,
		transcript,
		latestTurn,
		error,
		startCall,
		endCall,
		sendText,
		sendAudio
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxtQkFBbUI7QUFHekQsT0FBTyxTQUFTLFFBQ2QsaUJBQ0EsZ0JBQ0E7Q0FDQSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXFCLE1BQU07Q0FDdkQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQTJCLENBQUMsQ0FBQztDQUNqRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBNkIsSUFBSTtDQUNyRSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXdCLElBQUk7Q0FDdEQsTUFBTSxRQUFRLE9BQXlCLElBQUk7Q0FFM0MsTUFBTSxZQUFZLGtCQUFrQjtFQUNsQyxJQUFJLE1BQU0sV0FBVyxNQUFNLFFBQVEsZUFBZSxVQUFVLE1BQU07R0FDaEU7RUFDRjtFQUVBLFVBQVUsWUFBWTtFQUN0QixTQUFTLElBQUk7RUFDYixjQUFjLENBQUMsQ0FBQztFQUNoQixjQUFjLElBQUk7RUFFbEIsTUFBTSxXQUFXLE9BQU8sU0FBUyxhQUFhLFdBQVcsU0FBUztFQUNsRSxNQUFNLE9BQU8sT0FBTyxTQUFTOztFQUU3QixNQUFNLFFBQVEsR0FBRyxTQUFTLElBQUksS0FBSztFQUVuQyxNQUFNLEtBQUssSUFBSSxVQUFVLEtBQUs7RUFDOUIsTUFBTSxVQUFVO0VBRWhCLEdBQUcsZUFBZTtHQUNoQixVQUFVLFdBQVc7RUFDdkI7RUFFQSxHQUFHLGFBQWEsVUFBVTtHQUN4QixJQUFJO0lBQ0YsTUFBTSxNQUFxQixLQUFLLE1BQU0sTUFBTSxJQUFJO0lBQ2hELElBQUksSUFBSSxTQUFTLFFBQVE7S0FDdkIsY0FBYyxHQUFHOztLQUdqQixJQUFJLElBQUksYUFBYSxJQUFJLFVBQVUsS0FBSyxHQUFHO01BQ3pDLGVBQWUsU0FBUyxDQUN0QixHQUFHLE1BQ0g7T0FDRSxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJO09BQzlCLE1BQU0sSUFBSTtPQUNWLFNBQVM7T0FDVCxNQUFNLElBQUk7T0FDVixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CO01BQzNDLENBQ0YsQ0FBQztLQUNIOztLQUdBLElBQUksSUFBSSxZQUFZO01BQ2xCLGVBQWUsU0FBUyxDQUN0QixHQUFHLE1BQ0g7T0FDRSxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxJQUFJO09BQzlCLE1BQU0sSUFBSTtPQUNWLFNBQVM7T0FDVCxNQUFNLElBQUk7T0FDVixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CO09BQ3pDLFNBQVMsSUFBSTtPQUNiLE9BQU8sSUFBSTtNQUNiLENBQ0YsQ0FBQztLQUNIOztLQUdBLElBQUksSUFBSSxPQUFPO01BQ2Isa0JBQWtCLElBQUksT0FBTyxJQUFJLGNBQWMsWUFBWTtLQUM3RDtLQUVBLGlCQUFpQixHQUFHO0tBRXBCLElBQUksSUFBSSxVQUFVO01BQ2hCLFVBQVUsTUFBTTtLQUNsQjtJQUNGLE9BQU8sSUFBSSxJQUFJLFNBQVMsY0FBYztLQUNwQyxVQUFVLE1BQU07SUFDbEIsT0FBTyxJQUFJLElBQUksU0FBUyxTQUFTO0tBQy9CLFNBQVMsR0FBRyxJQUFJLE1BQU0sSUFBSSxJQUFJLFFBQVE7SUFDeEM7R0FDRixTQUFTLEtBQUs7SUFDWixRQUFRLE1BQU0sMkNBQTJDLEdBQUc7R0FDOUQ7RUFDRjtFQUVBLEdBQUcsV0FBVyxNQUFNO0dBQ2xCLFFBQVEsS0FBSyxvQkFBb0IsQ0FBQztHQUNsQyxTQUFTLGlGQUFpRjtHQUMxRixVQUFVLE1BQU07RUFDbEI7RUFFQSxHQUFHLGdCQUFnQjtHQUNqQixVQUFVLE1BQU07R0FDaEIsTUFBTSxVQUFVO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLGlCQUFpQixjQUFjLENBQUM7Q0FFcEMsTUFBTSxVQUFVLGtCQUFrQjtFQUNoQyxJQUFJLE1BQU0sV0FBVyxNQUFNLFFBQVEsZUFBZSxVQUFVLE1BQU07R0FDaEUsSUFBSTtJQUNGLE1BQU0sUUFBUSxLQUFLLEtBQUssVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDLENBQUM7R0FDcEQsU0FBUyxHQUFHO0lBQ1YsUUFBUSxLQUFLLDZCQUE2QixDQUFDO0dBQzdDO0dBQ0EsTUFBTSxRQUFRLE1BQU0sS0FBTSxhQUFhO0VBQ3pDO0VBQ0EsVUFBVSxNQUFNO0VBQ2hCLE1BQU0sVUFBVTtDQUNsQixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sV0FBVyxhQUNkLFNBQWlCO0VBQ2hCLElBQUksQ0FBQyxNQUFNLFdBQVcsTUFBTSxRQUFRLGVBQWUsVUFBVSxNQUFNO0dBQ2pFLFNBQVMsd0JBQXdCO0dBQ2pDO0VBQ0Y7RUFDQSxNQUFNLFVBQVUsS0FBSyxLQUFLO0VBQzFCLElBQUksQ0FBQyxTQUFTOztFQUdkLE1BQU0sUUFBUSxLQUFLLEtBQUssVUFBVTtHQUFFLE1BQU07R0FBYSxNQUFNO0VBQVEsQ0FBQyxDQUFDO0NBQ3pFLEdBQ0EsQ0FBQyxDQUNIO0NBRUEsTUFBTSxZQUFZLFlBQVksT0FBTyxjQUFrQztFQUNyRSxJQUFJLENBQUMsTUFBTSxXQUFXLE1BQU0sUUFBUSxlQUFlLFVBQVUsTUFBTTtHQUNqRSxTQUFTLHdCQUF3QjtHQUNqQztFQUNGO0VBRUEsSUFBSTtHQUNGLElBQUkscUJBQXFCLE1BQU07SUFDN0IsTUFBTSxTQUFTLE1BQU0sVUFBVSxZQUFZO0lBQzNDLE1BQU0sUUFBUSxLQUFLLE1BQU07R0FDM0IsT0FBTztJQUNMLE1BQU0sUUFBUSxLQUFLLFNBQVM7R0FDOUI7RUFDRixTQUFTLEtBQVU7R0FDakIsUUFBUSxNQUFNLCtCQUErQixHQUFHO0dBQ2hELFNBQVMseUNBQXlDO0VBQ3BEO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDZCxhQUFhO0dBQ1gsSUFBSSxNQUFNLFNBQVM7SUFDakIsTUFBTSxRQUFRLE1BQU07R0FDdEI7RUFDRjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZUNhbGwudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBDYWxsU3RhdHVzLCBTZXJ2ZXJNZXNzYWdlLCBUcmFuc2NyaXB0SXRlbSwgVHVybk1lc3NhZ2UgfSBmcm9tIFwiLi4vdHlwZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhbGwoXG4gIG9uQXVkaW9SZWNlaXZlZD86IChiYXNlNjQ6IHN0cmluZywgbWltZTogc3RyaW5nKSA9PiB2b2lkLFxuICBvblR1cm5Db21wbGV0ZT86ICh0dXJuOiBUdXJuTWVzc2FnZSkgPT4gdm9pZFxuKSB7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTxDYWxsU3RhdHVzPihcImlkbGVcIik7XG4gIGNvbnN0IFt0cmFuc2NyaXB0LCBzZXRUcmFuc2NyaXB0XSA9IHVzZVN0YXRlPFRyYW5zY3JpcHRJdGVtW10+KFtdKTtcbiAgY29uc3QgW2xhdGVzdFR1cm4sIHNldExhdGVzdFR1cm5dID0gdXNlU3RhdGU8VHVybk1lc3NhZ2UgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3Qgd3NSZWYgPSB1c2VSZWY8V2ViU29ja2V0IHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3Qgc3RhcnRDYWxsID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmICh3c1JlZi5jdXJyZW50ICYmIHdzUmVmLmN1cnJlbnQucmVhZHlTdGF0ZSA9PT0gV2ViU29ja2V0Lk9QRU4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRTdGF0dXMoXCJjb25uZWN0aW5nXCIpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHNldFRyYW5zY3JpcHQoW10pO1xuICAgIHNldExhdGVzdFR1cm4obnVsbCk7XG5cbiAgICBjb25zdCBwcm90b2NvbCA9IHdpbmRvdy5sb2NhdGlvbi5wcm90b2NvbCA9PT0gXCJodHRwczpcIiA/IFwid3NzOlwiIDogXCJ3czpcIjtcbiAgICBjb25zdCBob3N0ID0gd2luZG93LmxvY2F0aW9uLmhvc3Q7XG4gICAgLy8gSWYgcnVubmluZyB3aXRoIFZpdGUgZGV2IHNlcnZlciAocG9ydCA1MTczKSwgVml0ZSBwcm94eSByb3V0ZXMgL3dzIHRvIGJhY2tlbmQgd3M6Ly9sb2NhbGhvc3Q6ODAwMFxuICAgIGNvbnN0IHdzVXJsID0gYCR7cHJvdG9jb2x9Ly8ke2hvc3R9L3dzL2NhbGxzYDtcblxuICAgIGNvbnN0IHdzID0gbmV3IFdlYlNvY2tldCh3c1VybCk7XG4gICAgd3NSZWYuY3VycmVudCA9IHdzO1xuXG4gICAgd3Mub25vcGVuID0gKCkgPT4ge1xuICAgICAgc2V0U3RhdHVzKFwiY29ubmVjdGVkXCIpO1xuICAgIH07XG5cbiAgICB3cy5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IG1zZzogU2VydmVyTWVzc2FnZSA9IEpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG4gICAgICAgIGlmIChtc2cudHlwZSA9PT0gXCJ0dXJuXCIpIHtcbiAgICAgICAgICBzZXRMYXRlc3RUdXJuKG1zZyk7XG5cbiAgICAgICAgICAvLyBBZGQgdXNlciB0ZXh0IGlmIGl0IHdhcyB0cmFuc2NyaWJlZCBvciBlY2hvZWRcbiAgICAgICAgICBpZiAobXNnLnVzZXJfdGV4dCAmJiBtc2cudXNlcl90ZXh0LnRyaW0oKSkge1xuICAgICAgICAgICAgc2V0VHJhbnNjcmlwdCgocHJldikgPT4gW1xuICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaWQ6IGB1LSR7bXNnLnR1cm59LSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgICAgICAgIHR1cm46IG1zZy50dXJuLFxuICAgICAgICAgICAgICAgIHNwZWFrZXI6IFwidXNlclwiLFxuICAgICAgICAgICAgICAgIHRleHQ6IG1zZy51c2VyX3RleHQsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gQWRkIGFzc2lzdGFudCByZXBseVxuICAgICAgICAgIGlmIChtc2cucmVwbHlfdGV4dCkge1xuICAgICAgICAgICAgc2V0VHJhbnNjcmlwdCgocHJldikgPT4gW1xuICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgaWQ6IGBhLSR7bXNnLnR1cm59LSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgICAgICAgIHR1cm46IG1zZy50dXJuLFxuICAgICAgICAgICAgICAgIHNwZWFrZXI6IFwiYXNzaXN0YW50XCIsXG4gICAgICAgICAgICAgICAgdGV4dDogbXNnLnJlcGx5X3RleHQsXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpLFxuICAgICAgICAgICAgICAgIHRpbWluZ3M6IG1zZy50aW1pbmdzLFxuICAgICAgICAgICAgICAgIHN0YXRlOiBtc2cuc3RhdGUsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBFbnF1ZXVlIGF1ZGlvXG4gICAgICAgICAgaWYgKG1zZy5hdWRpbykge1xuICAgICAgICAgICAgb25BdWRpb1JlY2VpdmVkPy4obXNnLmF1ZGlvLCBtc2cuYXVkaW9fbWltZSB8fCBcImF1ZGlvL21wZWdcIik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgb25UdXJuQ29tcGxldGU/Lihtc2cpO1xuXG4gICAgICAgICAgaWYgKG1zZy5lbmRfY2FsbCkge1xuICAgICAgICAgICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAobXNnLnR5cGUgPT09IFwiY2FsbF9lbmRlZFwiKSB7XG4gICAgICAgICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cudHlwZSA9PT0gXCJlcnJvclwiKSB7XG4gICAgICAgICAgc2V0RXJyb3IoYCR7bXNnLmVycm9yfTogJHttc2cuZGV0YWlsfWApO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSBXZWJTb2NrZXQgSlNPTiBtZXNzYWdlOlwiLCBlcnIpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB3cy5vbmVycm9yID0gKGUpID0+IHtcbiAgICAgIGNvbnNvbGUud2FybihcIldlYlNvY2tldCBlcnJvcjpcIiwgZSk7XG4gICAgICBzZXRFcnJvcihcIldlYlNvY2tldCBjb25uZWN0aW9uIGZhaWxlZC4gRW5zdXJlIHRoZSBiYWNrZW5kIHNlcnZlciBpcyBydW5uaW5nIG9uIHBvcnQgODAwMC5cIik7XG4gICAgICBzZXRTdGF0dXMoXCJpZGxlXCIpO1xuICAgIH07XG5cbiAgICB3cy5vbmNsb3NlID0gKCkgPT4ge1xuICAgICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICAgIHdzUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gIH0sIFtvbkF1ZGlvUmVjZWl2ZWQsIG9uVHVybkNvbXBsZXRlXSk7XG5cbiAgY29uc3QgZW5kQ2FsbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAod3NSZWYuY3VycmVudCAmJiB3c1JlZi5jdXJyZW50LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5PUEVOKSB7XG4gICAgICB0cnkge1xuICAgICAgICB3c1JlZi5jdXJyZW50LnNlbmQoSlNPTi5zdHJpbmdpZnkoeyB0eXBlOiBcImVuZFwiIH0pKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS53YXJuKFwiRmFpbGVkIHRvIHNlbmQgZW5kIGZyYW1lOlwiLCBlKTtcbiAgICAgIH1cbiAgICAgIHdzUmVmLmN1cnJlbnQuY2xvc2UoMTAwMCwgXCJ1c2VyX2hhbmd1cFwiKTtcbiAgICB9XG4gICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICB3c1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNlbmRUZXh0ID0gdXNlQ2FsbGJhY2soXG4gICAgKHRleHQ6IHN0cmluZykgPT4ge1xuICAgICAgaWYgKCF3c1JlZi5jdXJyZW50IHx8IHdzUmVmLmN1cnJlbnQucmVhZHlTdGF0ZSAhPT0gV2ViU29ja2V0Lk9QRU4pIHtcbiAgICAgICAgc2V0RXJyb3IoXCJDYWxsIGlzIG5vdCBjb25uZWN0ZWQuXCIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0cmltbWVkID0gdGV4dC50cmltKCk7XG4gICAgICBpZiAoIXRyaW1tZWQpIHJldHVybjtcblxuICAgICAgLy8gU2VuZCBKU09OIGZyYW1lXG4gICAgICB3c1JlZi5jdXJyZW50LnNlbmQoSlNPTi5zdHJpbmdpZnkoeyB0eXBlOiBcInVzZXJfdGV4dFwiLCB0ZXh0OiB0cmltbWVkIH0pKTtcbiAgICB9LFxuICAgIFtdXG4gICk7XG5cbiAgY29uc3Qgc2VuZEF1ZGlvID0gdXNlQ2FsbGJhY2soYXN5bmMgKGF1ZGlvRGF0YTogQmxvYiB8IEFycmF5QnVmZmVyKSA9PiB7XG4gICAgaWYgKCF3c1JlZi5jdXJyZW50IHx8IHdzUmVmLmN1cnJlbnQucmVhZHlTdGF0ZSAhPT0gV2ViU29ja2V0Lk9QRU4pIHtcbiAgICAgIHNldEVycm9yKFwiQ2FsbCBpcyBub3QgY29ubmVjdGVkLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgaWYgKGF1ZGlvRGF0YSBpbnN0YW5jZW9mIEJsb2IpIHtcbiAgICAgICAgY29uc3QgYnVmZmVyID0gYXdhaXQgYXVkaW9EYXRhLmFycmF5QnVmZmVyKCk7XG4gICAgICAgIHdzUmVmLmN1cnJlbnQuc2VuZChidWZmZXIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgd3NSZWYuY3VycmVudC5zZW5kKGF1ZGlvRGF0YSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBhdWRpbyBieXRlczpcIiwgZXJyKTtcbiAgICAgIHNldEVycm9yKFwiRmFpbGVkIHRvIHN0cmVhbSBhdWRpbyBmcmFtZSB0byBzZXJ2ZXIuXCIpO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICh3c1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHdzUmVmLmN1cnJlbnQuY2xvc2UoKTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIHtcbiAgICBzdGF0dXMsXG4gICAgdHJhbnNjcmlwdCxcbiAgICBsYXRlc3RUdXJuLFxuICAgIGVycm9yLFxuICAgIHN0YXJ0Q2FsbCxcbiAgICBlbmRDYWxsLFxuICAgIHNlbmRUZXh0LFxuICAgIHNlbmRBdWRpbyxcbiAgfTtcbn1cbiJdfQ==