import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CallPanel.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4faeb0b1";
var _jsxFileName = "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/CallPanel.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4faeb0b1";
var _s = $RefreshSig$();
const QUICK_PROMPTS = [
	"Book a cleaning tomorrow at 10 AM",
	"I want to book an appointment",
	"Sara Khan",
	"0300-1234567",
	"Yes, confirm it",
	"Cancel my appointment",
	"Reschedule my appointment",
	"What services do you offer?",
	"Goodbye"
];
export function CallPanel({ status, transcript, isRecording, isPlayingAudio, error, startCall, endCall, sendText, startRecording, stopRecording }) {
	_s();
	const [inputText, setInputText] = useState("");
	const transcriptEndRef = useRef(null);
	useEffect(() => {
		transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [transcript]);
	const handleSend = () => {
		if (inputText.trim()) {
			sendText(inputText.trim());
			setInputText("");
		}
	};
	const handleKeyDown = (e) => {
		if (e.key === "Enter") {
			handleSend();
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "call-panel card",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-header",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "clinic-title-row",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "logo-icon",
						children: "🦷"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "BrightSmile Dental Assistant" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "subtitle",
						children: "Real-time Rule-Based Voice Agent (Deterministic FSM)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "status-badges",
					children: /* @__PURE__ */ _jsxDEV("span", {
						className: `status-pill ${status}`,
						children: [
							/* @__PURE__ */ _jsxDEV("span", { className: "dot" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 13
							}, this),
							status === "idle" && "Ready to Call",
							status === "connecting" && "Connecting...",
							status === "connected" && (isPlayingAudio ? "Speaking 🔊" : isRecording ? "Listening 🎙️" : "Call Active")
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "error-banner",
				children: ["⚠️ ", error]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "transcript-container",
				children: [transcript.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "empty-transcript",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "empty-icon",
							children: "📞"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", { children: "No Active Call" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: [
							"Click ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "Start Call" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 22
							}, this),
							" to initiate a session with the BrightSmile Voice Assistant."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "hint",
							children: "You can speak by holding the microphone button or type your message below."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this) : transcript.map((item) => /* @__PURE__ */ _jsxDEV("div", {
					className: `message-bubble ${item.speaker}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bubble-avatar",
						children: item.speaker === "assistant" ? "🤖" : "👤"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bubble-content",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bubble-meta",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "speaker-name",
										children: item.speaker === "assistant" ? "BrightSmile AI" : "Caller"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "timestamp",
										children: item.timestamp
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 103,
										columnNumber: 19
									}, this),
									item.state && /* @__PURE__ */ _jsxDEV("span", {
										className: "state-tag",
										children: item.state
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 34
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "message-text",
								children: item.text
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 17
							}, this),
							item.timings && /* @__PURE__ */ _jsxDEV("div", {
								className: "timing-note",
								children: [
									"⏱️ Total: ",
									Math.round(item.timings.total_ms),
									"ms (NLU: ",
									Math.round(item.timings.brain_ms),
									"ms, TTS: ",
									Math.round(item.timings.tts_ms),
									"ms)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 15
					}, this)]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 13
				}, this)), /* @__PURE__ */ _jsxDEV("div", { ref: transcriptEndRef }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 7
			}, this),
			status !== "idle" && /* @__PURE__ */ _jsxDEV("div", {
				className: "quick-prompts-row",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "prompts-label",
					children: "Quick Prompts:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "prompts-scroll",
					children: QUICK_PROMPTS.map((prompt, idx) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "chip-btn",
						onClick: () => sendText(prompt),
						children: prompt
					}, idx, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "call-controls",
				children: status === "idle" ? /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn btn-primary start-btn",
					onClick: startCall,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "btn-icon",
						children: "📞"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 13
					}, this), " Start Call"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: `btn push-to-talk-btn ${isRecording ? "recording" : ""}`,
						onMouseDown: startRecording,
						onMouseUp: stopRecording,
						onTouchStart: startRecording,
						onTouchEnd: stopRecording,
						title: status !== "connected" ? "Waiting for call to connect..." : "Click and hold to speak",
						disabled: status !== "connected",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "btn-icon",
							children: isRecording ? "🔴" : "🎙️"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 15
						}, this), status !== "connected" ? "Connecting..." : isRecording ? "Listening... (Release to send)" : "Hold to Speak"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-input-group",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							placeholder: "Or type what caller says...",
							value: inputText,
							onChange: (e) => setInputText(e.target.value),
							onKeyDown: handleKeyDown,
							disabled: status === "connecting"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn btn-secondary send-btn",
							onClick: handleSend,
							disabled: !inputText.trim(),
							children: "Send"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn btn-danger end-btn",
						onClick: endCall,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "btn-icon",
							children: "📵"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 15
						}, this), " Hang Up"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
}
_s(CallPanel, "RSs8lfR/hdKUGZl5gpSXhjhcgYs=");
_c = CallPanel;
var _c;
$RefreshReg$(_c, "CallPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CallPanel.tsx?t=1793812752729";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/CallPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/CallPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Importance/savvpro-test-voice-agent/dental-voice-assistant/frontend/src/components/CallPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7Ozs7QUFnQm5ELE1BQU0sZ0JBQWdCO0NBQ3BCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsT0FBTyxTQUFTLFVBQVUsRUFDeEIsUUFDQSxZQUNBLGFBQ0EsZ0JBQ0EsT0FDQSxXQUNBLFNBQ0EsVUFDQSxnQkFDQSxpQkFDaUI7O0NBQ2pCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxtQkFBbUIsT0FBOEIsSUFBSTtDQUUzRCxnQkFBZ0I7RUFDZCxpQkFBaUIsU0FBUyxlQUFlLEVBQUUsVUFBVSxTQUFTLENBQUM7Q0FDakUsR0FBRyxDQUFDLFVBQVUsQ0FBQztDQUVmLE1BQU0sbUJBQW1CO0VBQ3ZCLElBQUksVUFBVSxLQUFLLEdBQUc7R0FDcEIsU0FBUyxVQUFVLEtBQUssQ0FBQztHQUN6QixhQUFhLEVBQUU7RUFDakI7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLE1BQTZDO0VBQ2xFLElBQUksRUFBRSxRQUFRLFNBQVM7R0FDckIsV0FBVztFQUNiO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFZO0tBQU87Ozs7ZUFDbEMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSwrQkFBZ0M7Ozs7ZUFDcEMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQVc7S0FBdUQ7Ozs7YUFDNUU7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLGVBQWU7Z0JBQWhDO09BQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsTUFBTzs7Ozs7T0FDdEIsV0FBVyxVQUFVO09BQ3JCLFdBQVcsZ0JBQWdCO09BQzNCLFdBQVcsZ0JBQWdCLGlCQUFpQixnQkFBZ0IsY0FBYyxrQkFBa0I7TUFDekY7Ozs7OztJQUNIOzs7O1lBQ0Y7Ozs7OztHQUVKLFNBQVMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUE4QixPQUFJLEtBQVc7Ozs7OztHQUV2RCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0csV0FBVyxXQUFXLElBQ3JCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBYTtNQUFPOzs7OztNQUNuQyx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7OztNQUN0Qix3QkFBQyxLQUFEO09BQUc7T0FBTSx3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7O09BQUM7TUFBK0Q7Ozs7O01BQ25HLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFPO01BQTZFOzs7OztLQUM5Rjs7Ozs7ZUFFTCxXQUFXLEtBQUssU0FDZCx3QkFBQyxPQUFEO0tBQW1CLFdBQVcsa0JBQWtCLEtBQUs7ZUFBckQsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixLQUFLLFlBQVksY0FBYyxPQUFPO0tBQ3BDOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEtBQUssWUFBWSxjQUFjLG1CQUFtQjtTQUMvQzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBYSxLQUFLO1NBQWdCOzs7OztTQUNqRCxLQUFLLFNBQVMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWEsS0FBSztTQUFZOzs7OztRQUMxRDs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWdCLEtBQUs7T0FBVTs7Ozs7T0FDN0MsS0FBSyxXQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQTZCO1NBQ2hCLEtBQUssTUFBTSxLQUFLLFFBQVEsUUFBUTtTQUFFO1NBQVUsS0FBSyxNQUFNLEtBQUssUUFBUSxRQUFRO1NBQUU7U0FBVSxLQUFLLE1BQU0sS0FBSyxRQUFRLE1BQU07U0FBRTtRQUNoSTs7Ozs7O01BRUo7Ozs7O2FBQ0Y7T0FuQkssS0FBSzs7OztXQW1CVixDQUNOLEdBRUgsd0JBQUMsT0FBRCxFQUFLLEtBQUssaUJBQW1COzs7O1lBQzFCOzs7Ozs7R0FFSixXQUFXLFVBQ1Ysd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdCO0lBQW9COzs7O2NBQ3BELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osY0FBYyxLQUFLLFFBQVEsUUFDMUIsd0JBQUMsVUFBRDtNQUVFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxTQUFTLE1BQU07Z0JBRTdCO0tBQ0ssR0FORDs7OztZQU1DLENBQ1Q7SUFDRTs7OztZQUNGOzs7Ozs7R0FHUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFdBQVcsU0FDVix3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7S0FBNEIsU0FBUztlQUFyRSxDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFXO0tBQVE7Ozs7ZUFBQyxhQUM5Qjs7Ozs7ZUFFUjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVyx3QkFBd0IsY0FBYyxjQUFjO01BQy9ELGFBQWE7TUFDYixXQUFXO01BQ1gsY0FBYztNQUNkLFlBQVk7TUFDWixPQUFPLFdBQVcsY0FBYyxtQ0FBbUM7TUFDbkUsVUFBVSxXQUFXO2dCQVJ2QixDQVVFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFZLGNBQWMsT0FBTztNQUFZOzs7O2dCQUM1RCxXQUFXLGNBQ1Isa0JBQ0EsY0FDRSxtQ0FDQSxlQUNBOzs7Ozs7S0FFUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztPQUM1QyxXQUFXO09BQ1gsVUFBVSxXQUFXO01BQ3RCOzs7O2dCQUNELHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLFNBQVM7T0FDVCxVQUFVLENBQUMsVUFBVSxLQUFLO2lCQUMzQjtNQUVPOzs7O2NBQ0w7Ozs7OztLQUVMLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUF5QixTQUFTO2dCQUFsRSxDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXO01BQVE7Ozs7Z0JBQUMsVUFDOUI7Ozs7OztJQUNSOzs7OztHQUVEOzs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDYWxsUGFuZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgQ2FsbFN0YXR1cywgVHJhbnNjcmlwdEl0ZW0gfSBmcm9tIFwiLi4vdHlwZXNcIjtcblxuaW50ZXJmYWNlIENhbGxQYW5lbFByb3BzIHtcbiAgc3RhdHVzOiBDYWxsU3RhdHVzO1xuICB0cmFuc2NyaXB0OiBUcmFuc2NyaXB0SXRlbVtdO1xuICBpc1JlY29yZGluZzogYm9vbGVhbjtcbiAgaXNQbGF5aW5nQXVkaW86IGJvb2xlYW47XG4gIGVycm9yOiBzdHJpbmcgfCBudWxsO1xuICBzdGFydENhbGw6ICgpID0+IHZvaWQ7XG4gIGVuZENhbGw6ICgpID0+IHZvaWQ7XG4gIHNlbmRUZXh0OiAodGV4dDogc3RyaW5nKSA9PiB2b2lkO1xuICBzdGFydFJlY29yZGluZzogKCkgPT4gdm9pZDtcbiAgc3RvcFJlY29yZGluZzogKCkgPT4gdm9pZDtcbn1cblxuY29uc3QgUVVJQ0tfUFJPTVBUUyA9IFtcbiAgXCJCb29rIGEgY2xlYW5pbmcgdG9tb3Jyb3cgYXQgMTAgQU1cIixcbiAgXCJJIHdhbnQgdG8gYm9vayBhbiBhcHBvaW50bWVudFwiLFxuICBcIlNhcmEgS2hhblwiLFxuICBcIjAzMDAtMTIzNDU2N1wiLFxuICBcIlllcywgY29uZmlybSBpdFwiLFxuICBcIkNhbmNlbCBteSBhcHBvaW50bWVudFwiLFxuICBcIlJlc2NoZWR1bGUgbXkgYXBwb2ludG1lbnRcIixcbiAgXCJXaGF0IHNlcnZpY2VzIGRvIHlvdSBvZmZlcj9cIixcbiAgXCJHb29kYnllXCIsXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gQ2FsbFBhbmVsKHtcbiAgc3RhdHVzLFxuICB0cmFuc2NyaXB0LFxuICBpc1JlY29yZGluZyxcbiAgaXNQbGF5aW5nQXVkaW8sXG4gIGVycm9yLFxuICBzdGFydENhbGwsXG4gIGVuZENhbGwsXG4gIHNlbmRUZXh0LFxuICBzdGFydFJlY29yZGluZyxcbiAgc3RvcFJlY29yZGluZyxcbn06IENhbGxQYW5lbFByb3BzKSB7XG4gIGNvbnN0IFtpbnB1dFRleHQsIHNldElucHV0VGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgdHJhbnNjcmlwdEVuZFJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdHJhbnNjcmlwdEVuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xuICB9LCBbdHJhbnNjcmlwdF0pO1xuXG4gIGNvbnN0IGhhbmRsZVNlbmQgPSAoKSA9PiB7XG4gICAgaWYgKGlucHV0VGV4dC50cmltKCkpIHtcbiAgICAgIHNlbmRUZXh0KGlucHV0VGV4dC50cmltKCkpO1xuICAgICAgc2V0SW5wdXRUZXh0KFwiXCIpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IFJlYWN0LktleWJvYXJkRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgaGFuZGxlU2VuZCgpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FsbC1wYW5lbCBjYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLWhlYWRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsaW5pYy10aXRsZS1yb3dcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ28taWNvblwiPvCfprc8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgyPkJyaWdodFNtaWxlIERlbnRhbCBBc3Npc3RhbnQ8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VidGl0bGVcIj5SZWFsLXRpbWUgUnVsZS1CYXNlZCBWb2ljZSBBZ2VudCAoRGV0ZXJtaW5pc3RpYyBGU00pPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXR1cy1iYWRnZXNcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BzdGF0dXMtcGlsbCAke3N0YXR1c31gfT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRvdFwiIC8+XG4gICAgICAgICAgICB7c3RhdHVzID09PSBcImlkbGVcIiAmJiBcIlJlYWR5IHRvIENhbGxcIn1cbiAgICAgICAgICAgIHtzdGF0dXMgPT09IFwiY29ubmVjdGluZ1wiICYmIFwiQ29ubmVjdGluZy4uLlwifVxuICAgICAgICAgICAge3N0YXR1cyA9PT0gXCJjb25uZWN0ZWRcIiAmJiAoaXNQbGF5aW5nQXVkaW8gPyBcIlNwZWFraW5nIPCflIpcIiA6IGlzUmVjb3JkaW5nID8gXCJMaXN0ZW5pbmcg8J+Ome+4j1wiIDogXCJDYWxsIEFjdGl2ZVwiKX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImVycm9yLWJhbm5lclwiPuKaoO+4jyB7ZXJyb3J9PC9kaXY+fVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRyYW5zY3JpcHQtY29udGFpbmVyXCI+XG4gICAgICAgIHt0cmFuc2NyaXB0Lmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXRyYW5zY3JpcHRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wdHktaWNvblwiPvCfk548L2Rpdj5cbiAgICAgICAgICAgIDxoMz5ObyBBY3RpdmUgQ2FsbDwvaDM+XG4gICAgICAgICAgICA8cD5DbGljayA8c3Ryb25nPlN0YXJ0IENhbGw8L3N0cm9uZz4gdG8gaW5pdGlhdGUgYSBzZXNzaW9uIHdpdGggdGhlIEJyaWdodFNtaWxlIFZvaWNlIEFzc2lzdGFudC48L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoaW50XCI+WW91IGNhbiBzcGVhayBieSBob2xkaW5nIHRoZSBtaWNyb3Bob25lIGJ1dHRvbiBvciB0eXBlIHlvdXIgbWVzc2FnZSBiZWxvdy48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgdHJhbnNjcmlwdC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLmlkfSBjbGFzc05hbWU9e2BtZXNzYWdlLWJ1YmJsZSAke2l0ZW0uc3BlYWtlcn1gfT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUtYXZhdGFyXCI+XG4gICAgICAgICAgICAgICAge2l0ZW0uc3BlYWtlciA9PT0gXCJhc3Npc3RhbnRcIiA/IFwi8J+kllwiIDogXCLwn5GkXCJ9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1YmJsZS1jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUtbWV0YVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3BlYWtlci1uYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnNwZWFrZXIgPT09IFwiYXNzaXN0YW50XCIgPyBcIkJyaWdodFNtaWxlIEFJXCIgOiBcIkNhbGxlclwifVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGltZXN0YW1wXCI+e2l0ZW0udGltZXN0YW1wfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXRlICYmIDxzcGFuIGNsYXNzTmFtZT1cInN0YXRlLXRhZ1wiPntpdGVtLnN0YXRlfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXNzYWdlLXRleHRcIj57aXRlbS50ZXh0fTwvZGl2PlxuICAgICAgICAgICAgICAgIHtpdGVtLnRpbWluZ3MgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aW1pbmctbm90ZVwiPlxuICAgICAgICAgICAgICAgICAgICDij7HvuI8gVG90YWw6IHtNYXRoLnJvdW5kKGl0ZW0udGltaW5ncy50b3RhbF9tcyl9bXMgKE5MVToge01hdGgucm91bmQoaXRlbS50aW1pbmdzLmJyYWluX21zKX1tcywgVFRTOiB7TWF0aC5yb3VuZChpdGVtLnRpbWluZ3MudHRzX21zKX1tcylcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSlcbiAgICAgICAgKX1cbiAgICAgICAgPGRpdiByZWY9e3RyYW5zY3JpcHRFbmRSZWZ9IC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3N0YXR1cyAhPT0gXCJpZGxlXCIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aWNrLXByb21wdHMtcm93XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvbXB0cy1sYWJlbFwiPlF1aWNrIFByb21wdHM6PC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvbXB0cy1zY3JvbGxcIj5cbiAgICAgICAgICAgIHtRVUlDS19QUk9NUFRTLm1hcCgocHJvbXB0LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNoaXAtYnRuXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZW5kVGV4dChwcm9tcHQpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3Byb21wdH1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGwtY29udHJvbHNcIj5cbiAgICAgICAge3N0YXR1cyA9PT0gXCJpZGxlXCIgPyAoXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IHN0YXJ0LWJ0blwiIG9uQ2xpY2s9e3N0YXJ0Q2FsbH0+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJidG4taWNvblwiPvCfk548L3NwYW4+IFN0YXJ0IENhbGxcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYnRuIHB1c2gtdG8tdGFsay1idG4gJHtpc1JlY29yZGluZyA/IFwicmVjb3JkaW5nXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgIG9uTW91c2VEb3duPXtzdGFydFJlY29yZGluZ31cbiAgICAgICAgICAgICAgb25Nb3VzZVVwPXtzdG9wUmVjb3JkaW5nfVxuICAgICAgICAgICAgICBvblRvdWNoU3RhcnQ9e3N0YXJ0UmVjb3JkaW5nfVxuICAgICAgICAgICAgICBvblRvdWNoRW5kPXtzdG9wUmVjb3JkaW5nfVxuICAgICAgICAgICAgICB0aXRsZT17c3RhdHVzICE9PSBcImNvbm5lY3RlZFwiID8gXCJXYWl0aW5nIGZvciBjYWxsIHRvIGNvbm5lY3QuLi5cIiA6IFwiQ2xpY2sgYW5kIGhvbGQgdG8gc3BlYWtcIn1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N0YXR1cyAhPT0gXCJjb25uZWN0ZWRcIn1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnRuLWljb25cIj57aXNSZWNvcmRpbmcgPyBcIvCflLRcIiA6IFwi8J+Ome+4j1wifTwvc3Bhbj5cbiAgICAgICAgICAgICAge3N0YXR1cyAhPT0gXCJjb25uZWN0ZWRcIlxuICAgICAgICAgICAgICAgID8gXCJDb25uZWN0aW5nLi4uXCJcbiAgICAgICAgICAgICAgICA6IGlzUmVjb3JkaW5nXG4gICAgICAgICAgICAgICAgICA/IFwiTGlzdGVuaW5nLi4uIChSZWxlYXNlIHRvIHNlbmQpXCJcbiAgICAgICAgICAgICAgICAgIDogXCJIb2xkIHRvIFNwZWFrXCJ9XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk9yIHR5cGUgd2hhdCBjYWxsZXIgc2F5cy4uLlwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2lucHV0VGV4dH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0VGV4dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVLZXlEb3dufVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzdGF0dXMgPT09IFwiY29ubmVjdGluZ1wifVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi1zZWNvbmRhcnkgc2VuZC1idG5cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlbmR9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpbnB1dFRleHQudHJpbSgpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU2VuZFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLWRhbmdlciBlbmQtYnRuXCIgb25DbGljaz17ZW5kQ2FsbH0+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJ0bi1pY29uXCI+8J+TtTwvc3Bhbj4gSGFuZyBVcFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==